<?php echo Html::style('/css/bootstrap.min.css'); ?>

<?php echo Html::style('/css/datatables.css'); ?>

<?php echo Html::script('/js/bootstrap.min.js'); ?>


<?php echo Html::script('/js/jquery-1.11.3.min.js'); ?>

<?php echo Html::script('/js/datatables.js'); ?>


<!--<?php echo Form::model($query, [
    'method' => 'PATCH',
    'route' => ['mycont.update', $query->id]
]); ?>-->
<table class="table table-hover">
    <?php echo Form::hidden('id',$query->id,array('class'=>'form-control','id'=>'id')); ?>

    
    <tr>
        <th>Flat Type</th>
        <td><?php echo Form::text('edit_flat_type',$query->flat_type,array('class'=>'form-control','id'=>'edit_flat_type')); ?></td>
        
        
    </tr>
    <tr>
    <th>Monthly Rent</th>
        <td><?php echo Form::text('edit_monthly_rent',$query->monthly_rent,array('class'=>'form-control','id'=>'edit_monthly_rent')); ?></td>
        
        
    </tr>
    
    
    
<!--    <tr>
        <td></td>
        <td><?php echo Form::submit('update',['class'=>'btn btn-success']); ?></td>
    </tr>-->
    
</table>
<!--<?php echo Form::close(); ?>-->