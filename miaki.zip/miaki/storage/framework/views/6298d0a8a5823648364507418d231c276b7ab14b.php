<html>
    <title></title>
    <head>
    </head>
    <body>
        
    
<p><h1 style="font-weight: bold" align="center">Real Estate Management System</h1>
    <h3 style="font-weight: bold" align="center">Rampura Dhaka 1219</h3>
    <h3 style="font-weight: bold" align="center">Cell: 01916580472</h3>
</p>

<table class="table table-hover example mytable" border="1" width="100%">
<?php echo e($i=1); ?>

<thead>
<tr>
<th>Sl</th>
<th>Client Name</th>
<th>Flat Type</th>
<th>Payment Type</th>
<th>Monthly Installment</th>
<th>Monthly Rent</th>


</tr>
</thead>
<?php $__currentLoopData = $query; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
<tr>
<td><?php echo e($i++); ?></td>
<td><?php echo e($row->client_name); ?></td>
<td><?php echo e($row->flat_type); ?></td>
<td><?php echo e($row->payment_type); ?></td>
<td><?php echo e($row->monthly_installment); ?></td>
<td><?php echo e($row->monthly_rent); ?></td>

</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
</table>
<br><br>

<div style="text-align: right; font-style: italic; margin-right: 30px">Document created by Rasel Ahsan</div>
</body>
</html>