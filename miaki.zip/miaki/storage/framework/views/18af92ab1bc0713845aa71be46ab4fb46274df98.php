<?php echo Html::style('/css/bootstrap.min.css'); ?>

<?php echo Html::script('/js/jquery-1.12.3.min.js'); ?>

<?php echo Html::script('/js/bootstrap.min.js'); ?>


<table class="table table-hover">
    <tr>
        <th>Sale</th>
        <td><?php echo $query->Sale; ?></td>        
    </tr>
    
    <tr>
        <th>Not Sale</th>
        <td><?php echo $query->Not_Sale; ?></td>        
    </tr>
    <tr>
        <th>Flat Type</th>
        <td><?php echo $query->Flat_Type; ?></td>        
    </tr>  
</table>





