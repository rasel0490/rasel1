<?php echo Html::style('/css/bootstrap.min.css'); ?>

<?php echo Html::script('/js/jquery-1.12.3.min.js'); ?>

<?php echo Html::script('/js/bootstrap.min.js'); ?>

<!--<?php echo Form::model($query, [
    'method' => 'PATCH',
    'route' => ['mycount.update', $query->Allotment_ID]
]); ?>-->
<table class="table table-hover">
<?php echo Form::hidden('id',$query->Allotment_ID,array('class'=>'form-control','id'=>'id')); ?>

    <tr>
        <th>Client Name</th>
        <td><?php echo Form::text('edit_client_name',$query->Client_Name,array('class'=>'form-control','id'=>'edit_client_name')); ?></td>


    </tr>
    <tr>
        <th>Flat Type</th>
        <td><?php echo Form::text('edit_flat_type',$query->Flat_Type,array('class'=>'form-control','id'=>'edit_flat_type')); ?></td>

    </tr>
    <tr>
        <th>Total Amount</th>
        <td><?php echo Form::text('edit_total_amount',$query->Total_Amount,array('class'=>'form-control','id'=>'edit_total_amount')); ?></td>

    </tr>
    <tr>
        <th>Monthly Amount</th>
        <td><?php echo Form::text('edit_monthly_amount',$query->Monthly_Amount,array('class'=>'form-control','id'=>'edit_monthly_amount')); ?></td>

    </tr>
    <tr>
        <th>Duration</th>
        <td><?php echo Form::text('edit_duration',$query->Duration,['class'=>'form-control']); ?></td>

    </tr>
    <tr>
        <th>Balance</th>
        <td><?php echo Form::text('edit_balance',$query->Balance,array('class'=>'form-control','id'=>'edit_balance')); ?></td>

    </tr>
    <tr>
        <th>Late Interest</th>
        <td><?php echo Form::text('edit_with_late_interest',$query->With_Late_Interest,array('class'=>'form-control','id'=>'edit_with_late_interest')); ?></td>

    </tr>
</table>
<!--<?php echo Form::close(); ?>-->



