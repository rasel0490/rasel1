<?php echo Html::style('/css/bootstrap.min.css'); ?>

<?php echo Html::script('/js/jquery-1.12.3.min.js'); ?>

<?php echo Html::script('/js/bootstrap.min.js'); ?>

<table class="table table-hover">
   <?php echo Form::hidden('id',$query->Client_ID,array('class'=>'form-control','id'=>'id')); ?>

    <tr>
        <th>Client Name</th>
        <td><?php echo Form::text('edit_client_name',$query->Client_Name,array('class'=>'form-control','id'=>'edit_client_name')); ?></td>
        
        
    </tr>
    <tr>
        <th>Client Address</th>
        <td><?php echo Form::text('edit_client_address',$query->Client_Address,array('class'=>'form-control','id'=>'edit_client_address')); ?>

    </tr>
      <tr>
        <th>Client Phone</th>
        <td><?php echo Form::text('edit_client_phone',$query->Client_Phone,array('class'=>'form-control','id'=>'edit_client_phone')); ?></td>
        
    </tr>
      <tr>
        <th>Client Email</th>
        <td><?php echo Form::text('edit_client_email',$query->Client_Email,array('class'=>'form-control','id'=>'edit_client_email')); ?></td>
        
    </tr>
   <tr><th>Image Upload</th>
    
        <td><?php echo Form::file('edit_image'); ?></td>
    </tr>
    
</table>
