<!DOCTYPE HTML>
<html>
<head>
<script type="text/javascript">
window.onload = function () {
	var chart = new CanvasJS.Chart("chartContainer",
	{
		title: {
			text: "Using formatDate inside Custom Formatter"
		},
		axisX: {
			labelFormatter: function (e) {
				return CanvasJS.formatDate( e.value, "DD MMM");
			},
		},
		
		data: [
		{
			type: "spline",
			dataPoints: [
//				{ x: new Date(2010, 0, 3), y: 50 },
//				{ x: new Date(2010, 0, 5), y: 100 },
//				{ x: new Date(2010, 0, 7), y: 110 },
//				{ x: new Date(2010, 0, 9), y: 158 },
//				{ x: new Date(2010, 0, 11), y: 34 },
//				{ x: new Date(2010, 0, 13), y: 363 },
//				{ x: new Date(2010, 0, 15), y: 247 },
//				{ x: new Date(2010, 0, 17), y: 253 },
//				{ x: new Date(2010, 0, 19), y: 269 },
//				{ x: new Date(2010, 0, 21), y: 343 },
//				{ x: new Date(2010, 0, 23), y: 370 }
			   <?php foreach($query as $row){ ?>
				  { x: <?php echo $row->cv_id?>, y: <?php echo $row->status?>},
                                  
                                  <?php }?>
                    ]
		}
		]                      
	});
	chart.render();
}
</script>
<script type="text/javascript" src="js/canvasjs.min.js"></script>
</head>
<body>
<div id="chartContainer" style="height: 350px; width: 100%;"></div>
</body>
</html>
       