<?php echo Html::style('/css/bootstrap.min.css'); ?>

<?php echo Html::style('/css/datatables.css'); ?>

<?php echo Html::script('/js/jquery-1.11.3.min.js'); ?>

<?php echo Html::script('/js/bootstrap.min.js'); ?>

<?php echo Html::script('/js/datatables.js'); ?>

    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <body style="background-color:#076F91">
         <a href="rent_info_print" class="" ><img class="img-responsive" src="images/print_icon.png" alt="print"></a>

    <p><h1 style="font-weight: bold" align="center">Real Estate Management System</h1>
    <h3 style="font-weight: bold" align="center">Rampura Dhaka 1219</h3>
    <h3 style="font-weight: bold" align="center">Cell: 01916580472</h3>
</p>
<!--    //<a href="Rent_Info.index" class="btn btn-default">Home</a>-->
<a style="margin: 10px 0px 10px 0px; " href="template" class="btn btn-md btn-default" >Home</a>
   <button style="margin: 10px 0px 10px 0px" data-toggle="modal" data-target="#add_user" class="btn btn-md btn-primary">Add+</button>
<div id="add_user" class="modal fade" role="dialog">
    <div class="modal-dialog modal-md">
       <?php echo Form::open(array('method'=>'post','id'=>'save')); ?>

        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>    
            </div>
            
            <div class="modal-body">
                <table class="table table-hover" id="view_user">
    
    <tr>
        <th>Flat Type</th>
        <td>
<!--            <?php echo Form::select('flat_type',array('A'=>'A','B'=>'B','C'=>'C','D'=>'D'),null,['class'=>'form-control','id'=>'flat_type','onkeyup'=>'formValidation(id)','onchange'=>'formValidation(id)']); ?>-->
            <?php echo Form::select('flat_type',array('A'=>'A','B'=>'B','C'=>'C','D'=>'D'),null,['class'=>'form-control','id'=>'flat_type','onkeyup'=>'formValidation(id)','onchange'=>'formValidation(id)']); ?>

        </td>
        
        
    </tr>
    <tr><td></td> <td id="flat_type_error" style="color:red"></td></tr>
    <tr>
        <th>Monthly Rent</th>
        <td><?php echo Form::text('monthly_rent','',array(
    'class'=>'form-control',
    'id'=>'monthly_rent',
    'onkeyup'=>'formValidation(id)',
    'onchange'=>'formValidation(id)'
            
            )); ?></td>
        
    </tr>
    <tr><td></td> <td id="monthly_rent_error" style="color:red"></td></tr>
                </table>
    
            </div>
            
             <div class="modal-footer">
               <?php echo Form::button('save',array('class'=>'btn btn-success btn-sm','onclick'=>'save_data()')); ?>

                
               <?php echo Form::button('Cancel',array('class'=>'btn btn-danger btn-sm','data-dismiss'=>'modal')); ?>

               
<!--               <buttonn type="button" class="btn btn-sm btn-success" data-dismiss="modal">No</button>-->
            </div>
            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
        <?php echo Form::close(); ?>

        </div>
    </div>
</div>




<table class="table table-hover example mytable" width="100%">
<?php echo e($i=1); ?>

<thead>
<tr>
<th>Sl</th>
<th>Flat Type</th>
<th>Monthly Rent</th>
<th>Delete</th>
<th>Edit</th>
<!--<th>View</th>-->
</tr>
</thead>
<?php $__currentLoopData = $query; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
<tr>
<td><?php echo e($i++); ?></td>
<td><?php echo e($row->flat_type); ?></td>
<td><?php echo e($row->monthly_rent); ?></td>

<td>
<!--<?php echo Form::open([
'method'=>'DELETE',
'route'=>['mycont.destroy',$row->id]
]); ?>-->

<!--<?php echo Form::submit('Delete',['class'=>'btn btn-danger']); ?>-->
<?php echo Form::button('Delete',array('class'=>'btn btn-danger','data-toggle'=>'modal','data-target'=>'#delete_nc','id'=>$row->id)); ?>


</td>
<td><?php echo Form::button('Edit',array('class'=>'btn btn-info','data-toggle'=>'modal','data-target'=>'#update','id'=>$row->id,'onclick'=>"updateUserForm(id)")); ?></td>

<!--<td><a href="<?php echo e(route('mycont.edit',$row->id)); ?>" class="btn btn-info">Edit</a></td>-->
<!--<td><a href="<?php echo e(route('mycont.edit',$row->id)); ?>" class="btn btn-success">View</a></td>-->
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>


</table>

<!--<?php echo Form::close(); ?>-->

<!-- Delete Modal Start -->
<div id="delete_nc" class="modal fade" role="dialog">
    <div class="modal-dialog modal-md">

         Modal content
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <img src="images/warning.png"> <strong style="color: red">WARNING !</strong>
            </div>
            <div class="modal-body">
                <input type="hidden" id="pre_id" value="">
                Are you sure you want to delete this record ?<br>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-sm btn-danger" id="delete">Yes</button>
                <button type="button" class="btn btn-sm btn-success" data-dismiss="modal">No</button>
            </div>
        </div>
    </div>
</div>
<!-- Delete Modal End-->
<!-- Modal for update Starts Here -->
<div id="update" class="modal fade" role="dialog">
    <div class="modal-dialog modal-lg">

        <!-- Modal content-->
        <?php echo Form::open(array('method'=>'post','id'=>'update_c')); ?>

<!--        <form id="update_c"  method="post" enctype="multipart/form-data">-->
 <?php //echo form_open_multipart('home/updateleftmenuse');?>
        <div class="modal-content" style="">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <strong>Update Rent Information</strong>
            </div>
            <div class="modal-body">
                
                <div id="up"></div>
            </div>
            <div class="modal-footer">
                <input type="button" class="btn btn-sm btn-success" onclick="updateData()" value="Update">
        <button type="button" class="btn btn-sm btn-danger" data-dismiss="modal">Cancel</button>
    </div>
        </div>
     
        <?php echo Form::close(); ?>

    </div>
</div>
<!-- Modal for update Ends Here -->


</body>
<script>
    window.Laravel = <?php echo json_encode([
        'csrfToken' => csrf_token(),
    ]); ?>
</script>

<script>
function save_data(){
    var form=$('#save').get(0);
  //  var base_url="<?php echo e(URL::to('/')); ?>";
    var flat_type=$('select[name=flat_type]').val();
    var monthly_rent=$('input[name=monthly_rent]').val();
    var token=$('input[name=_token]').val();
    
    if(flat_type===""|| monthly_rent===""){
        
        if(flat_type===""){
        $('#flat_type_error').html("Please Enter Your Flat type");
        $('#flat_type').css('border-color','red');
    }
    if(monthly_rent===""){
        $('#monthly_rent_error').html("Please Enter Monthly Rent");
        $('#monthly_rent').css('border-color','red');
    }
    }else{
       $.ajax({
          
           url:'rent_info_save_data',
           method:'post',
           data:{
               'flat_type':flat_type,
               'monthly_rent':monthly_rent,
               '_token':token
                },
            dataType:'HTML',    
           success: function(data){
               $('#add_user').modal('hide');
              window.location.assign('<?php  redirect('rent_info');?>');
//             $('#view_user').html(data);
           }
       }); 
    }   
}

$(document).ready(function(){
     $('.mytable').delegate('button','click',function(event){
    var id=event.target.id;  
    $('#pre_id').val(id);
        });
    
     $('#delete').click(function(){
        var id=$('#pre_id').val();
       var token=$('input[name=_token]').val();
        $.ajax({
            url: 'delete_rentinfo',
            method: 'post',
            data:{id:id,_token:token},
            success: function(){
              window.location.assign('<?php  redirect('rent_info');?>');
            }
            
        });
        
    });
    
    
    });
    function updateUserForm(ida){
         var token=$('input[name=_token]').val();
                
                $.ajax({
                url: 'rent_info_edit',
                method: 'post',
                data: {id:ida,_token:token},
                success: function (data) {
                    $('#up').html(data);
                }
        });
        
    }
    
    function updateData(){
        
        var flat_type=$.trim($('input[name=edit_flat_type]').val());
          
    var monthly_rent=$.trim($('input[name=edit_monthly_rent]').val());
    var token=$('input[name=_token]').val();
    var id=$('input[name=id]').val();
//      alert(id);
            $.ajax({
                url: 'update_rentinfo',
                method: 'post',
                  data: {
                      'flat_type':flat_type,
                      'monthly_rent':monthly_rent,
                      '_token':token,
                      'id':id
                      
                  },
                  dataType:'HTML',
                 
               success: function(data){                   
                    //$('#update').modal('hide');
                    window.location.assign('<?php redirect('rent_info');?>');
                  
                }
            });
    }
</script>

<script>
$(document).ready(function(){
    
 $('.example').dataTable();   
    
});

function formValidation(id){
    var val=$.trim($('#'+id).val());
    if(val===''){
        $('#'+id+'_error').html('');
        $('#'+id).css('border-color','red');
        
    }else{
        $('#'+id+'_error').html('');
        $('#'+id).css('border-color','green');
        
    }
    
    
}
</script>
