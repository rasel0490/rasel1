<?php if(!$abc=Session::get('sess_user_name')): ?>
<script type="text/javascript">
    window.location = "<?php echo e(url('login')); ?>";//here double curly bracket
</script>
<?php echo e($abc); ?>

<?php endif; ?>
<?php echo Html::style('/css/bootstrap.min.css'); ?>

<?php echo Html::style('/css/bootstrap-social.css'); ?>

<?php echo Html::style('/css/font-awesome.css'); ?>


<?php echo Html::style('/css/datatables.css'); ?>

<?php echo Html::script('/js/bootstrap.min.js'); ?>

<?php echo Html::script('/js/datatables.js'); ?>

<?php echo Html::script('/js/jquery-1.11.3.min.js'); ?>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link href="http://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet">
    <link href="<?php echo e(URL::asset('http://fonts.googleapis.com/css?family=Montserrat')); ?>" rel="stylesheet">
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Real Estate Co.</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="css/styles.css" rel="stylesheet" type="text/css" />
</head>
    <body style="background-color: #3333ff">
        <div id="container" style="background-color: #dbeef8; width: 90%;">
            <div class="row" style="background-color:#d9ff66;  margin:0px -4px 0px -3px">
                <div class="col-lg-5 col-md-5 col-sm-5" style=" margin-left: 0px">
                    <img class="img-responsive"  src="images/logo.gif" alt="" name="" width="150px" height="35" id=""/>
                </div>
                
                 <div class="col-lg-7 col-md-7 col-sm-7">
                     <ul class="nav navbar-nav" style="font-size: 16px">
      <li class="btn_1"><a href="http://wpsi29.com/userfiles/rasel.php">Home</a></li>
      <li class="btn_2"><a href="http://www.wpsi29.com/rasel/wp/?page_id=16">about us</a></li>
      <li class="btn_3"><a href="rent_info">Rent Info</a></li>
      <li class="btn_4"><a href="money_recept">Money Recept</a></li>
      <li class="btn_5"><a href="rent_info_report">Report</a></li>
      <li class="btn_5"><a href="client_info">Client info </a></li>
      <li class="btn_5"><a href="puser">payment head </a></li>
      <li class="btn_5"><a href="allotoment_status">Allotoment Status</a></li>
      <li class="btn_5"><a href="allotment_price_installment">Allotment Installment </a></li>
      <li class="btn_5"><a href="client_info">Project info </a></li>
      <li class="btn_5"><a href="logout">Logout</a></li>
    </ul>
                </div>
            </div>
           
            
            <div id="header" style="margin-right: -20px"> <img class="img-responsive" src="images/slogan.jpg" alt="" name="logo" width="400px" height="74" id="slogan"/> </div>
  <!--start content-->
  <div class="row" style="">
                <div class="col-lg-9 col-md-9 col-sm-9" style="background-color:">
      <div class="row">
          
          <div class="col-lg-12 col-md-12 col-sm-12" style="margin-left: 10px">
        
        <img src="images/img_welcome.jpg" width="100" height="103" alt="" />
        <h2 style="float: right; color: #99cc00; font-weight: bold;font-size: 40px; margin: 20px 180px 0px 0px">Welcome ours Company!</h2>
        <p style="font-size: 16px"><span class="headline">Sed vestibulum. Integer in ante. Sed posuere ligula</span> Lorem ipsum dolor sit amet, consectetuer adipiscing elit.
            Nam eu nulla. Donec lobortis purus vel urna. <a href="#">Nunc laoreet lacinia</a> nunc. In volutpat sodales ipsum. Sed vestibulum. Integer in ante.
            Sed posuere ligula Sed vestibulum. Integer in ante. Sed posuere ligula</span> Lorem ipsum dolor sit amet, consectetuer adipiscing elit.Sed vestibulum. 
        Integer in ante. Sed posuere ligula</span> Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Nam eu nulla. Donec lobortis purus vel urna.
        <a href="#">Nunc laoreet lacinia</a> nunc. In volutpat sodales ipsum. Sed vestibulum. </p>
        <div class="clear"></div>
          </div>
          
      </div>
        <br></br><br></br>
        <div class="row" style="margin-left: 20px">
        <h2 style=" color: #99cc00; font-weight: bold;font-size: 40px; margin: 0px 0px 5px 10px">Featured Homes</h2>
        <div class="col-lg-6 col-md-6 col-sm-6" > <img src="images/img_featured300x150.jpg" width="300" height="150" alt="" />
          <p style="font-size: 24px" class="headline">Sed vestibulum. Integer in ante. </p>
          <ul style="font-size: 20px; margin-top: 10px">
            <li><a href="#">Lorem ipsum dolor sit amet, </a></li>
            <li><a href="#">consectetuer adipiscing elit. Nam eu </a></li>
            <li><a href="#">nulla. Donec lobortis purus vel urna.</a></li>
            <li><a href="#">Nunc laoreet lacinia nunc. In </a></li>
          </ul>
        </div>
        <div class="col-lg-6 col-md-6 col-sm-6"> <img src="images/img_featured-05.jpg" width="300" height="150" alt="" />
          <p style="font-size: 24px" class="headline">Sed vestibulum. Integer in ante. </p>
          <ul style="font-size: 20px; margin-top: 10px">
            <li><a href="#">Lorem ipsum dolor sit amet, </a></li>
            <li><a href="#">consectetuer adipiscing elit. Nam eu </a></li>
            <li><a href="#">nulla. Donec lobortis purus vel urna.</a></li>
            <li><a href="#">Nunc laoreet lacinia nunc. In </a></li>
          </ul>
        </div>
        <div class="clear"></div>
      </div>
    </div>
    <div class="col-lg-3 col-md-3 col-sm-3" style="  ">
        <div id="news" style="font-size: 20p">
        <h2></h2>
        <p><span class="headline">20.09.2009</span> Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Nam eu nulla. </p>
        <p><span class="headline">19.09.2009</span> Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Nam eu nulla. </p>
        <p><span class="headline">18.09.2009</span> Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Nam eu nulla. </p>
      </div>
      <div id="mortgage">
        <h2></h2>
        <p> <span class="headline">Integer vel magna. Quisque ut magna et nisi bibendum sagittis. </span>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Nam eu nulla. <a href="#">Donec lobortis purus vel urna.</a> Nunc laoreet lacinia nunc. In volutpat sodales ipsum. Sed vestibulum. Integer in ante. Sed posuere ligula </p>
      </div>
    </div>
    <div class="clear" id="end"></div>
  </div>
  <!--end content-->
  <div class=row">
      <div class="col-lg-12 col-md-12 col-sm-12" align="center" style="background-color:  #86b300; padding-bottom: 30px">
          <p><a href="#">HOME PAGE</a> | <a href="#">ABOUT US</a> | <a href="#">CATALOGUE</a> | <a href="#">SUPPORT</a> | <a href="#">CONTACTS</a><br/>
      Copyright &copy; Wosi29 | Design by <a href="http://wpsi29.com/userfiles/rasel.php">Rasel Ahsan</a></p>
 
          <div class=" text-right">
<a class="btn btn-social-icon btn-facebook">
<span class="fa fa-facebook"></span>

</a>
<a class="btn btn-social-icon btn-twitter">
<span class="fa fa-twitter"></span>

</a>

<a class="btn btn-social-icon btn-danger">
<span class="fa fa-youtube"></span>

</a>
<a class="btn btn-social-icon btn-linkedin">
<span class="fa fa-linkedin"></span>

</a>

</div>
      </div>
      
    </div>
</div>
</body>
</html>
