<!--<?php if(!$abc=Session::get('sess_user_name')): ?>
<script type="text/javascript">
    window.location = "<?php echo e(url('login')); ?>";//here double curly bracket
</script>
<?php echo e($abc); ?>

<?php endif; ?>-->

<?php echo Html::style('/css/bootstrap.min.css'); ?>

<?php echo Html::style('/css/datatables.css'); ?>

<?php echo Html::script('/js/jquery-1.12.3.min.js'); ?>

<?php echo Html::script('/js/datatables.js'); ?>

<?php echo Html::script('/js/bootstrap.js'); ?>

<?php echo Html::script('/js/bootstrap.min.js'); ?>

<h1 align="center">East West Property Development (Pvt.) Ltd.</h1>
<h2 align="center"> Dhanmondi,Dhaka</h2>
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<body style="background-color:#3D7ACC;">
     <a style="margin: 0px 0px 10px 0px; " href="template" class="btn btn-md btn-default" >Home</a>
<button data-toggle="modal" data-target="#add_user" class="btn btn-large btn-primary">Add+</button>
<a href="print_payment" class="btn btn-success" >Print</a>
<a href="logout" class="btn btn-danger">Logout</a>
<div id="add_user" class="modal fade" role="dialog">
    <div class="modal-dialog modal-md">
       <?php echo Form::open(array('method'=>'post','id'=>'save')); ?>

        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
<div class="modal-body">
                <table class="table table-hover" id="view_user">
             <tr>
        <th>Steel Cost</th>
        <td><?php echo Form::text('steel_cost','',array(
    'class'=>'form-control',
    'id'=>'steel_cost',
    'onkeyup'=>'formValidation(id)',
    'onchange'=>'formValidation(id)'
            )); ?></td>
        </tr>
    <tr><td></td> <td id="steel_cost_error" style="color:red"></td></tr>
             <tr>
        <th>Labour Cost</th>
        <td><?php echo Form::text('labour_cost','',array(
    'class'=>'form-control',
    'id'=>'labour_cost',
    'onkeyup'=>'formValidation(id)',
    'onchange'=>'formValidation(id)'
            )); ?></td>
        </tr>
    <tr><td></td> <td id="labour_cost_error" style="color:red"></td></tr>
    
        <tr>
        <th>Employee Cost</th>
        <td><?php echo Form::text('employee_cost','',array(
    'class'=>'form-control',
    'id'=>'employee_cost',
    'onkeyup'=>'formValidation(id)',
    'onchange'=>'formValidation(id)'
            )); ?></td>
        </tr>
    <tr><td></td> <td id="employee_cost_error" style="color:red"></td></tr>
    
            <tr>
        <th>Advertising Cost</th>
        <td><?php echo Form::text('advertising_cost','',array(
    'class'=>'form-control',
    'id'=>'advertising_cost',
    'onkeyup'=>'formValidation(id)',
    'onchange'=>'formValidation(id)'
            )); ?></td>
        </tr>
    <tr><td></td> <td id="advertising_cost_error" style="color:red"></td></tr>
        <tr>
        <th>Other Cost</th>
        <td><?php echo Form::text('other_cost','',array(
    'class'=>'form-control',
    'id'=>'other_cost',
    'onkeyup'=>'formValidation(id)',
    'onchange'=>'formValidation(id)'
            )); ?></td>
        </tr>
    <tr><td></td> <td id="other_cost_error" style="color:red"></td></tr>
                </table>
             </div>
            <div class="modal-footer">
               <?php echo Form::button('save',array('class'=>'btn btn-success btn-sm','onclick'=>'save_data()')); ?>

                
               <?php echo Form::button('Cancel',array('class'=>'btn btn-danger btn-sm','data-dismiss'=>'modal')); ?>

               
<!--               <buttonn type="button" class="btn btn-sm btn-success" data-dismiss="modal">No</button>-->
            </div>
            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
        <?php echo Form::close(); ?>

        </div>
    </div>
    </div> 
<table class="table table-hover example mytable" border="" width="100%" style="background-color: ">
 <div id="table_body">
<thead>
<tr>
<th>Sl</th>
<th>Steel Cost</th>
<th>Labour Cost</th>
<th>Employee Cost</th>
<th>Advertising Cost</th>
<th>Other Cost</th>
<th>Delete</th>
<th>Update</th>
<th>View</th>


</tr>
</thead>
 <?php echo e($i=1); ?>

<?php $__currentLoopData = $query; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
<tr>
<td><?php echo e($i++); ?></td>
<td><?php echo e($row->Steel_Cost); ?></td>
<td><?php echo e($row->Labour_Cost); ?></td>
<td><?php echo e($row->Employee_Cost); ?></td>
<td><?php echo e($row->Advertising_Cost); ?></td>
<td><?php echo e($row->Other_Cost); ?></td>
<td>
<?php echo Form::button('Delete',array('class'=>'btn btn-danger','data-toggle'=>'modal','data-target'=>'#delete_nc','id'=>$row->Payment_ID)); ?>

</td>

<td><?php echo Form::button('Edit',array('class'=>'btn btn-info','data-toggle'=>'modal','data-target'=>'#update_nc','id'=>$row->Payment_ID,'onclick'=>"updateUserForm(id)")); ?></td>
<th><?php echo Form::button('View',array('class'=>'btn btn-info','data-toggle'=>'modal','data-target'=>'#viewD','id'=>$row->Payment_ID,'onclick'=>"viewDetails(id)")); ?></th>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>


</table>
</div>
     <!-- Insert Model End --> 
     <!-- Delete Modal Start -->
<div id="delete_nc" class="modal fade" role="dialog">
    <div class="modal-dialog modal-md">

         Modal content
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <img src="image/warning.png"> <strong style="color: red">WARNING !</strong>
            </div>
            <div class="modal-body">
                <input type="hidden" id="pre_id" value="">
                Are you sure you want to delete this record ?<br>
            </div>
            <div class="modal-footer">
                <button class="btn btn-sm btn-danger" id="delete">Yes</button>
                <button type="button" class="btn btn-sm btn-success" data-dismiss="modal">No</button>
            </div>
        </div>
    </div>
</div>
<!-- Delete Modal End-->
<!-- Modal for update Starts Here -->
<div id="update_nc" class="modal fade" role="dialog">
    <div class="modal-dialog modal-lg">
        <?php echo Form::open(array('method'=>'post','id'=>'update_c')); ?>

<div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <strong>Update User Client Info</strong>
            </div>
            <div class="modal-body" id="table_body">
                
                <div id="up"></div>
            </div>
            <div class="modal-footer">
                <input type="button" class="btn btn-sm btn-success" onclick="updateData()" value="Update">
        <button type="button" class="btn btn-sm btn-primary" data-dismiss="modal">Cancel</button>
    </div>
        </div>
     
        <?php echo Form::close(); ?>

    </div>
</div>
<!-- Modal for update Ends Here -->

<!-- Modal for view Starts Here -->
<div id="viewD" class="modal fade" role="dialog">
    <div class="modal-dialog modal-lg">

        <!-- Modal content-->
       
<!--        <form id="update_c"  method="post" enctype="multipart/form-data">-->
 <?php //echo form_open_multipart('home/updateleftmenuse');?>
        <div class="modal-content" style="">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <strong>View Payment</strong>
            </div>
            <div class="modal-body" id="table_body">
                
                <div id="view_data1"></div>
            </div>
            <div class="modal-footer">

    </div>
        </div>
     
        
    </div>
</div>
<!-- Modal for update Ends Here -->
    </body>
<!-- End Modal-->
<script>
    window.Laravel = <?php echo json_encode([
        'csrfToken' => csrf_token(),
    ]); ?>
</script>
<script>
function save_data(){
    var form=$('#save').get(0);
  //  var base_url="<?php echo e(URL::to('/')); ?>";
    var steel_cost=$('input[name=steel_cost]').val();
    var labour_cost=$('input[name=labour_cost]').val();
     var employee_cost=$('input[name=employee_cost]').val();
    var advertising_cost=$('input[name=advertising_cost]').val();
    var other_cost=$('input[name=other_cost]').val();
     var token=$('input[name=_token]').val();
    
    if(steel_cost==""|| labour_cost=="" || employee_cost==""|| advertising_cost=="" || other_cost=="" ){
        
        if(steel_cost==""){
        $('#steel_cost_error').html("Please Enter Your steel cost");
        $('#steel_cost').css('border-color','red');
    }
    if(labour_cost==""){
        $('#labour_cost_error').html("Please Enter labour cost");
        $('#labour_cost').css('border-color','red');
    }
    if(employee_cost==""){
        $('#employee_cost_error').html("Please Enter employee cost");
        $('#employee_cost').css('border-color','red');
    }
    if(advertising_cost==""){
        $('#advertising_cost_error').html("Please Enter advertising cost");
        $('#advertising_cost').css('border-color','red');
    }
    if(other_cost==""){
        $('#other_cost_error').html("Please Enter other cost");
        $('#other_cost').css('border-color','red');
    }
    
    }else{
      
       $.ajax({
          
           url:'save_data2',
           method:'post',
           data:{
               'steel_cost':steel_cost,
               'labour_cost':labour_cost,
                'employee_cost':employee_cost,
               'advertising_cost':advertising_cost,
               'other_cost':other_cost,
               '_token':token
           
                },
           dataType:'HTML',    
           success: function(data){
          
        $('#add_user').modal('hide');
        window.location.assign('<?php redirect('puser');?>');
           }
       });
 }
}

$(document).ready(function(){
        $('.mytable').delegate('button','click',function(event){
    var id=event.target.id;
  
    $('#pre_id').val(id);
    
    });
    
     $('#delete').click(function(){
        var id=$('#pre_id').val();
       var token=$('input[name=_token]').val();
        $.ajax({
            url: 'delete_data2',
            method: 'post',
            data:{id:id,_token:token},
            success: function(){
              window.location.assign('<?php redirect('puser');?>');
            }
            
        });
        
    });
    });
    
       function updateUserForm(ida){
         var token=$('input[name=_token]').val();
                
                $.ajax({
                url:'edit_form1',
                method:'post',
                data: {id:ida,_token:token},
                success:function(data){
                    $('#up').html(data);
                }
        });
        
    }
    
      function viewDetails(idb){
         var token=$('input[name=_token]').val();
                
                $.ajax({
                url: 'view_payment',
                method: 'post',
                data: {id:idb,_token:token},
                success: function (data) {
                    $('#view_data1').html(data);
                }
        })
        
    }
    
      function updateData(){
        
        var steel_cost=$.trim($('input[name=edit_steel_cost]').val());
         var labour_cost=$.trim($('input[name=edit_labour_cost]').val());
      var employee_cost=$.trim($('input[name=edit_employee_cost]').val());
        var advertising_cost=$.trim($('input[name=edit_advertising_cost]').val());
      var other_cost=$.trim($('input[name=edit_other_cost]').val());     
    var token=$('input[name=_token]').val();
    var id=$('input[name=id]').val();
//      alert(id);
            $.ajax({
                url: 'update_data1',
                method: 'post',
                  data: {
                     'steel_cost':steel_cost,
               'labour_cost':labour_cost,
                'employee_cost':employee_cost,
               'advertising_cost':advertising_cost,
               'other_cost':other_cost,
                      '_token':token,
                      'id':id
                      
                  },
                  dataType:'HTML',    
           success:function(data){          
        $('#update_nc').modal('hide');
        window.location.assign('<?php redirect('puser');?>');
                  
                }
            });
    }
    

</script>


<script>
$(document).ready(function(){
	
	$('.example').dataTable();
	
});
function formValidation(id){
    var val=$.trim($('#'+id).val());
    if(val===''){
        $('#'+id+'_error').html('');
        $('#'+id).css('border-color','red');
        
    }else{
        $('#'+id+'_error').html('');
        $('#'+id).css('border-color','green');
        }}


</script>