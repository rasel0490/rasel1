<?php if(!$abc=Session::get('sess_user_name')): ?>
<script type="text/javascript">
    window.location = "<?php echo e(url('login')); ?>";//here double curly bracket
</script>
<?php echo e($abc); ?>

<?php endif; ?>
<?php echo Html::style('/css/bootstrap.min.css'); ?>

<?php echo Html::style('/css/datatables.css'); ?>

<?php echo Html::script('/js/jquery-1.12.3.min.js'); ?>

<?php echo Html::script('/js/bootstrap.min.js'); ?>

<?php echo Html::script('/js/datatables.js'); ?>

<?php echo Html::script('/js/bootstrap.js'); ?>

<style>
    img{
        height: 70px;
        width:70px;
    }
</style>
<h1 align="center">East West Property Development (Pvt.) Ltd.</h1>
<h2 align="center"> Dhanmondi,Dhaka</h2>
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<body style="background-color:">
    <a style="margin: 0px 0px 10px 0px; " href="template" class="btn btn-md btn-default" >Home</a>
<button data-toggle="modal" data-target="#add_user" class="btn btn-large btn-primary">Add+</button> 
<a href="print_user" class="btn btn-success" >Print</a>
<a href="report" class="btn btn-success" >Report</a>
<a href="logout" class="btn btn-danger">Logout</a>
<div id="add_user" class="modal fade" role="dialog">
    <div class="modal-dialog modal-md">
       <?php echo Form::open(array('method'=>'post','id'=>'save','files'=>'true')); ?>

        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                
            </div>

         <div class="modal-body">
                <table class="table table-hover" id="view_user">
                     <tr>
        <th>Client Name</th>
        <td><?php echo Form::text('client_name','',array(
    'class'=>'form-control',
    'id'=>'client_name',
    'onkeyup'=>'formValidation(id)',
    'onchange'=>'formValidation(id)'
            )); ?></td>
        </tr>
    <tr><td></td> <td id="client_name_error" style="color:red"></td></tr>
    
             <tr>
        <th>Client Address</th>
        <td><?php echo Form::text('client_address','',array(
    'class'=>'form-control',
    'id'=>'client_address',
    'onkeyup'=>'formValidation(id)',
    'onchange'=>'formValidation(id)'
            
            )); ?></td>
        </tr>
    <tr><td></td> <td id="client_address_error" style="color:red"></td></tr>
        <tr>
        <th>Client Phone</th>
        <td><?php echo Form::text('client_phone','',array(
    'class'=>'form-control',
    'id'=>'client_phone',
    'onkeyup'=>'formValidation(id)',
    'onchange'=>'formValidation(id)'
            
            )); ?></td>
        </tr>
    <tr><td></td> <td id="client_phone_error" style="color:red"></td></tr>
    <tr>
        <th>Client Email</th>
        <td><?php echo Form::text('client_email','',array(
    'class'=>'form-control',
    'id'=>'client_email',
    'onkeyup'=>'formValidation(id)',
    'onchange'=>'formValidation(id)'
            
            )); ?></td>
        </tr>
    <tr><td></td> <td id="client_email_error" style="color:red"></td></tr>
    
    <tr><th>Image Upload</th>
    
        <td><?php echo Form::file('image'); ?></td>
    </tr>
                </table>
              </div>
            <div class="modal-footer">
               <?php echo Form::button('save',array('class'=>'btn btn-success btn-sm','onclick'=>'save_data()')); ?>

                
               <?php echo Form::button('Cancel',array('class'=>'btn btn-danger btn-sm','data-dismiss'=>'modal')); ?>

               
               
            </div>
            <input type="hidden" name="_token" id="_token" value="<?php echo e(csrf_token()); ?>">
        <?php echo Form::close(); ?>

        </div>
    </div>
    
</div> 

<table class="table table-hover example mytable" border="1" width="100%">
    <div id="table_body">

<thead>
<tr>
<th>Sl</th>
<th>Client Name</th>
<th>Client Address</th>
<th>Client Phone</th>
<th>Client Email</th>
<th>Picture</th>
<th>Delete</th>
<th>Update</th>
<th>View</th>
</tr>
</thead>
<?php echo e($i=1); ?>

<?php $__currentLoopData = $query; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
<tr>
<td><?php echo e($i++); ?></td>
<td><?php echo e($row->Client_Name); ?></td>
<td><?php echo e($row->Client_Address); ?></td>
<td><?php echo e($row->Client_Phone); ?></td>
<td><?php echo e($row->Client_Email); ?></td>
<td><?php echo e(HTML::image('uploads/'.$row->Client_Picture)); ?></td>
<td>
<?php echo Form::button('Delete',array('class'=>'btn btn-danger','data-toggle'=>'modal','data-target'=>'#delete_nc','id'=>$row->Client_ID)); ?>

</td>

<th><?php echo Form::button('Edit',array('class'=>'btn btn-info','data-toggle'=>'modal','data-target'=>'#update_nc','id'=>$row->Client_ID,'onclick'=>"updateUserForm(id)")); ?></th>
<th><?php echo Form::button('View',array('class'=>'btn btn-info','data-toggle'=>'modal','data-target'=>'#viewD','id'=>$row->Client_ID,'onclick'=>"viewDetails(id)")); ?></th>

</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
</table>
    </div>
<!-- Insert Model End --> 
 <!-- Modal for update Starts Here -->
<div id="update_nc" class="modal fade" role="dialog">
    <div class="modal-dialog modal-lg">
        <?php echo Form::open(array('method'=>'post','id'=>'update_c','files'=>'true')); ?>

<div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <strong>Update User Client Info</strong>
            </div>
            <div class="modal-body" id="table_body">
                
                <div id="up"></div>
            </div>
            <div class="modal-footer">
                <input type="button" class="btn btn-sm btn-success" onclick="updateData()" value="Update">
        <button type="button" class="btn btn-sm btn-primary" data-dismiss="modal">Cancel</button>
    </div>
        </div>
     
        <?php echo Form::close(); ?>

    </div>
</div>
<!-- Modal for update Ends Here -->
 
 <!-- Delete Modal Start -->
<div id="delete_nc" class="modal fade" role="dialog">
    <div class="modal-dialog modal-md">

         Modal content
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <img src="images/warning.jpg"> <strong style="color: red">WARNING !</strong>
            </div>
            <div class="modal-body">
                <input type="hidden" id="pre_id" value="">
                Are you sure you want to delete this record ?<br>
            </div>
            <div class="modal-footer">
                <button class="btn btn-sm btn-danger" id="delete">Yes</button>
                <button type="button" class="btn btn-sm btn-success" data-dismiss="modal">No</button>
            </div>
        </div>
    </div>
</div>
<!-- Delete Modal End-->


<!-- Modal for view Starts Here -->
<div id="viewD" class="modal fade" role="dialog">
    <div class="modal-dialog modal-lg">

        <!-- Modal content-->
       
<!--        <form id="update_c"  method="post" enctype="multipart/form-data">-->
 <?php //echo form_open_multipart('home/updateleftmenuse');?>
        <div class="modal-content" style="">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <strong></strong>
            </div>
            <div class="modal-body" id="table_body">
                
                <div id="view_data"></div>
            </div>
            <div class="modal-footer">

    </div>
        </div>
     
        
    </div>
</div>
<!-- Modal for update Ends Here -->
</body>
<script>
    window.Laravel = <?php echo json_encode([
        'csrfToken' => csrf_token(),
    ]); ?>
</script>
<script>
$(document).ready(function(){
	
	$('.example').dataTable();
	
});
function formValidation(id){
    var val=$.trim($('#'+id).val());
    if(val===''){
        $('#'+id+'_error').html('');
        $('#'+id).css('border-color','red');
        
    }else{
        $('#'+id+'_error').html('');
        $('#'+id).css('border-color','green');
        }
    }
    </script>
<script>
function save_data(){
    var form=$('#save').get(0);
  //  var base_url="<?php echo e(URL::to('/')); ?>";
    var client_name=$('input[name=client_name]').val();
    var client_address=$('input[name=client_address]').val();
     var client_phone=$('input[name=client_phone]').val();
    var client_email=$('input[name=client_email]').val();
    var client_picture=$('input[name=image]').val();
     var token=$('input[name=_token]').val();
    
    if(client_name==""|| client_address=="" || client_phone==""|| client_email=="" ){
        
        if(client_name==""){
        $('#client_name_error').html("Please Enter Your client name");
        $('#client_name').css('border-color','red');
    }
    if(client_address==""){
        $('#client_address_error').html("Please Enter client address");
        $('#client_address').css('border-color','red');
    }
    if(client_phone==""){
        $('#client_phone_error').html("Please Enter client phone");
        $('#client_phone').css('border-color','red');
    }
    if(client_email==""){
        $('#client_email_error').html("Please Enter client email");
        $('#client_email').css('border-color','red');
    }
    
    }else{
      $.ajax({
          
           url:'client_info_save_data',
           method:'post',
//           data:{
////               'client_name':client_name,
////               'client_address':client_address,
////                'client_phone':client_phone,
////               'client_email':client_email,
////               '_token':token
////           
////                },
////            dataType:'HTML',    
           data: new FormData(form),
            processData:false,
            contentType:false,
           success: function(){
          
        $('#add_user').modal('hide');
        window.location.assign('<?php redirect('client_info');?>');
       
      }
       });
        
    }
       
 }
 
 $(document).ready(function(){
        $('.mytable').delegate('button','click',function(event){
    var id=event.target.id;
  $('#pre_id').val(id);
    });
    
     $('#delete').click(function(){
        var id=$('#pre_id').val();
       var token=$('input[name=_token]').val();
        $.ajax({
            url: 'client_info_delete_data',
            method: 'post',
            data:{id:id,_token:token},
            success: function(){
              window.location.assign('<?php redirect('client_info');?>');
            }
            
        });
        
    });
    });
    function updateUserForm(ida){
         var token=$('input[name=_token]').val();
                $.ajax({
                url:'client_info_edit_form',
                method:'post',
                data: {id:ida,_token:token},
                success:function(data){
                    $('#up').html(data);
                }
        });
        }
        
            function viewDetails(idb){
         var token=$('input[name=_token]').val();
                
                $.ajax({
                url: 'view_data',
                method: 'post',
                data: {id:idb,_token:token},
                success: function (data) {
                    $('#view_data').html(data);
                }
        })
        
    }
    
     function updateData(){
           var form=$('#update_c').get(0);
        var client_name=$.trim($('input[name=edit_client_name]').val());   
    var client_address=$.trim($('input[name=edit_client_address]').val());
      var client_phone=$.trim($('input[name=edit_client_phone]').val());
       var client_email=$.trim($('input[name=edit_client_email]').val());
        var client_picture=$.trim($('input[name=edit_image]').val());
    var token=$('input[name=_token]').val();
    var id=$('input[name=id]').val();
//      alert(id);
            $.ajax({
                url: 'update_data',
                method: 'post',
//                  data: {
//                     'client_name':client_name,
//               'client_address':client_address,
//                'client_phone':client_phone,
//               'client_email':client_email,
//               'edit_image':client_picture,
//                      '_token':token,
//                      'id':id
//                      },
//                  dataType:'HTML', 
  data: new FormData(form),
            processData:false,
            contentType:false,
           success:function(data){          
//        $('#update_nc').modal('hide');
        window.location.assign('<?php redirect('client_info');?>');
                  
                }
            });
    }   
    </script>
