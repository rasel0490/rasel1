

<?php echo Html::script('/js/jquery-1.11.3.min.js'); ?>

<?php echo Html::script('/js/bootstrap.min.js'); ?>


<style>
    img{
        height: 180px;
        width:150px;
    }
</style>
<!--<?php echo e(print_r($query)); ?>-->
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<table style="font-weight: bold" class=""  align="center" style="float: right" width="100%">
     <?php $__currentLoopData = $query; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
    <tr>  <caption style="font-size: 34px; color:Green;text-align: center">Resume of <?php echo $row->appl_name; ?></caption></tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
</table>
<!--<table style="font-weight: bold" class=""  align="center" style="float: right" width="100%">
    <?php $__currentLoopData = $query; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
    <tr>  <caption style="font-size: 34px; color:Green;text-align: center">Resume of <?php echo $row->appl_name; ?></caption></tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>;
</table>-->
<table style="height: 160px; width: 150px;" class="" style=" margin-bottom: 10px; padding-bottom: 20px" align="right" width="20%">
    <?php $__currentLoopData = $query; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
   
    <tr><td><?php echo e(Html::image('uploads/'.$row->appl_picture)); ?></td></tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
</table>
<!--<table style="height: 160px; width: 150px;" class="" style="" align="right" width="20%">
   <?php $__currentLoopData = $query; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
   
    <tr><td><?php echo e(Html::image('uploads/'.$row->appl_picture)); ?></td></tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>;
</table>-->

<table class=" " width="100%" style="margin-top: 200px">
<!--<?php echo e($i=1); ?>


<tr><th>Sl</th><td><?php echo $i++; ?></td></tr>-->

<?php $__currentLoopData = $query; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
<tr><td>Father Name:</td><td class=""><?php echo $row->father_name; ?></td></tr>
<tr><td>Mother Name:</td><td class=""><?php echo $row->mother_name; ?></td></tr>
<tr><td>Gender:</td><td class=""><?php echo $row->gender; ?></td></tr>
<tr><td>Parmanent Address:</td><td class=""><?php echo $row->parmanent_address; ?></td></tr>
<tr><td>Present Address:</td><td class=""><?php echo $row->present_address; ?></td></tr>
<tr><td>Date of Birth:</td><td class=""><?php echo $row->birthday; ?></td></tr>
<tr><td>Education:</td><td class=""><?php echo $row->education; ?></td></tr>
<tr><td>Religion:</td><td class=""><?php echo $row->relegion; ?></td></tr>
<tr><td>Nationality</td><td class=""><?php echo $row->nationality; ?></td></tr>
<tr><td>National ID<td class=""><?php echo $row->nid; ?></td></tr>
<tr><td>handicape</td><td class=""><?php echo $row->handicape; ?></td></tr>
<tr><td>Phone No</td><td class=""><?php echo $row->phone; ?></td></tr>

<tr><td>Email</td><td class=""><?php echo $row->email; ?></td></tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
</table>