<?php echo Html::style('/css/bootstrap.min.css'); ?>

<?php echo Html::script('/js/jquery-1.12.3.min.js'); ?>

<?php echo Html::script('/js/bootstrap.min.js'); ?>


<table class="table table-hover">
    <tr>
        <th>Client Name</th>
        <td><?php echo $query->Client_Name; ?></td>        
    </tr>
    
    <tr>
        <th>Flat Type</th>
        <td><?php echo $query->Flat_Type; ?></td>        
    </tr>
    <tr>
        <th>Total Amount</th>
        <td><?php echo $query->Total_Amount; ?></td>        
    </tr>
    <tr>
        <th>Monthly Amount</th>
        <td><?php echo $query->Monthly_Amount; ?></td>        
    </tr>    
</table>

