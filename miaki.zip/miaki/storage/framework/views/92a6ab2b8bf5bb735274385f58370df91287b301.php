<?php echo Html::style('/css/bootstrap.min.css'); ?>

<?php echo Html::style('/css/datatables.css'); ?>

<?php echo Html::style('/css/jquery-ui.css'); ?>

<?php echo Html::style('/css/BuroRaDer.DateRangePicker.css'); ?>

<?php echo Html::script('/js/jquery-1.11.3.min.js'); ?>

<?php echo Html::script('/js/bootstrap.min.js'); ?>

<!--<?php echo Html::script('/js/jquery.mobile-1.4.5.js'); ?>-->
<!--<?php echo Html::script('/js/jquery-migrate-3.0.0.min.js'); ?>-->
<?php echo Html::script('/js/jquery-ui.js'); ?>

<?php echo Html::script('/js/datatables.js'); ?>

<?php echo Html::script('/js/BuroRaDer.DateRangePicker.js'); ?>

  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>"> 
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Infinity carieer</title>
    <link href="css/bootstrap-social.css" rel="stylesheet"/>
<link href="css/font-awesome.css" rel="stylesheet"/>
<link href="http://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,700,300italic,400italic,700italic" rel="stylesheet" type="text/css">
<link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
<link rel=”stylesheet” id=”font-awesome-css” href=”//netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css” type=”text/css” media=”screen”>   
<script src="js/jssor.slider-21.1.6.min.js"></script>
    <script type="text/javascript">
        jQuery(document).ready(function ($) {

            var jssor_1_SlideoTransitions = [
              [{b:-1,d:1,o:-1},{b:0,d:1000,o:1}],
              [{b:1900,d:2000,x:-379,e:{x:7}}],
              [{b:1900,d:2000,x:-379,e:{x:7}}],
              [{b:-1,d:1,o:-1,r:288,sX:9,sY:9},{b:1000,d:900,x:-1400,y:-660,o:1,r:-288,sX:-9,sY:-9,e:{r:6}},{b:1900,d:1600,x:-200,o:-1,e:{x:16}}]
            ];

            var jssor_1_options = {
              $AutoPlay: true,
              $SlideDuration: 800,
              $SlideEasing: $Jease$.$OutQuint,
              $CaptionSliderOptions: {
                $Class: $JssorCaptionSlideo$,
                $Transitions: jssor_1_SlideoTransitions
              },
              $ArrowNavigatorOptions: {
                $Class: $JssorArrowNavigator$
              },
              $BulletNavigatorOptions: {
                $Class: $JssorBulletNavigator$
              }
            };

            var jssor_1_slider = new $JssorSlider$("jssor_1", jssor_1_options);

            /*responsive code begin*/
            /*you can remove responsive code if you don't want the slider scales while window resizing*/
            function ScaleSlider() {
                var refSize = jssor_1_slider.$Elmt.parentNode.clientWidth;
                if (refSize) {
                    refSize = Math.min(refSize, 1920);
                    jssor_1_slider.$ScaleWidth(refSize);
                }
                else {
                    window.setTimeout(ScaleSlider, 30);
                }
            }
            ScaleSlider();
            $(window).bind("load", ScaleSlider);
            $(window).bind("resize", ScaleSlider);
            $(window).bind("orientationchange", ScaleSlider);
            /*responsive code end*/
        });

    </script>
    
    <script>
 
jQuery(document).ready(function() {
 
var offset = 250;
 
var duration = 300;
 
jQuery(window).scroll(function() {
 
if (jQuery(this).scrollTop() > offset) {
 
jQuery(‘.back-to-top’).fadeIn(duration);
 
} else {
 
jQuery(‘.back-to-top’).fadeOut(duration);
 
}
 
});
 
 
 
jQuery(‘.back-to-top’).click(function(event) {
 
event.preventDefault();
 
jQuery(‘html, body’).animate({scrollTop: 0}, duration);
 
return false;
 
})
 
});
 
</script>
    
    <style>
        /* jssor slider bullet navigator skin 05 css */
        /*
        .jssorb05 div           (normal)
        .jssorb05 div:hover     (normal mouseover)
        .jssorb05 .av           (active)
        .jssorb05 .av:hover     (active mouseover)
        .jssorb05 .dn           (mousedown)
        */
        .jssorb05 {
            position: absolute;
        }
        .jssorb05 div, .jssorb05 div:hover, .jssorb05 .av {
            position: absolute;
            /* size of bullet elment */
            width: 16px;
            height: 16px;
            background: url('img/b05.png') no-repeat;
            overflow: hidden;
            cursor: pointer;
        }
        .jssorb05 div { background-position: -7px -7px; }
        .jssorb05 div:hover, .jssorb05 .av:hover { background-position: -37px -7px; }
        .jssorb05 .av { background-position: -67px -7px; }
        .jssorb05 .dn, .jssorb05 .dn:hover { background-position: -97px -7px; }

        /* jssor slider arrow navigator skin 22 css */
        /*
        .jssora22l                  (normal)
        .jssora22r                  (normal)
        .jssora22l:hover            (normal mouseover)
        .jssora22r:hover            (normal mouseover)
        .jssora22l.jssora22ldn      (mousedown)
        .jssora22r.jssora22rdn      (mousedown)
        .jssora22l.jssora22lds      (disabled)
        .jssora22r.jssora22rds      (disabled)
        */
        .jssora22l, .jssora22r {
            display: block;
            position: absolute;
            /* size of arrow element */
            width: 40px;
            height: 58px;
            cursor: pointer;
            background: url('img/a22.png') center center no-repeat;
            overflow: hidden;
        }
        .jssora22l { background-position: -10px -31px; }
        .jssora22r { background-position: -70px -31px; }
        .jssora22l:hover { background-position: -130px -31px; }
        .jssora22r:hover { background-position: -190px -31px; }
        .jssora22l.jssora22ldn { background-position: -250px -31px; }
        .jssora22r.jssora22rdn { background-position: -310px -31px; }
        .jssora22l.jssora22lds { background-position: -10px -31px; opacity: .3; pointer-events: none; }
        .jssora22r.jssora22rds { background-position: -70px -31px; opacity: .3; pointer-events: none; }
        


.back-to-top {
 
background: none;
 
margin: 0;
 
position: fixed;
 
bottom: 0;
 
right: 0;
 
width: 70px;
 
height: 70px;
 
z-index: 100;
 
display: none;
 
text-decoration: none;
 
color: #ffffff;
 
background-color: #ff9000;
 
}
 
  
 
.back-to-top i {
 
  font-size: 60px;
 
}
    </style>
    
    <script language="javascript">
  document.onmousedown = disableclick;
  status = "Right Click Disabled";
  Function disableclick(e)
  {
    if(event.button == 2)
    {
      alert(status);
      return false; 
    }
  }
</script>
    
    <script type="text/javascript">
    $(function() {
      
      
      $("#datepicker").datepicker({
        dateFormat: 'yy-mm-dd'
      });
      
    });
  </script>
</head>
<body style="background-color: #058518"  oncontextmenu="return false">
     <!-- Navigation -->
    <nav class="navbar " role="navigation"  style="background-color: #0cdf2c;">
        
            <!-- Brand and toggle get grouped for better mobile display -->
            
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse mynav" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav navbar-left" >
                    <li>
                        <a href="http://www.wpsi29.com/userfiles/rasel.php" style="color:#010902; font-weight: bold; font-size: 20px;">HOME</a>
                    </li>
                    <li>
                        <button style=" margin-top: 5px; margin-bottom: 5px;" data-toggle="modal" data-target="#add_user" class=""><img class="img-responsive" src="images/drop_cv.png" alt="insert"></button>
                    </li>
                </ul>
                    <ul class="nav navbar-nav navbar-right" >
                    <li>
                        <a href="#" style="color:#010902; font-weight: bold; font-size: 20px;">Help</a>
                    </li>
			<li>
                        <a href="login" style="color:#010902; font-weight: bold; font-size: 20px;">login</a>
                    </li>		
                </ul>
            </div>
        
    </nav>
            <!-- /.navbar-collapse -->
    <div class="container" style="background-color:#0ef4c7">
       
        
        <!--start marquee -->
        <div class="row"  style="background-color: #73dfe2">
<div class="col-sm-12 news">
                <div class="col-sm-2">
                    <h4>Latest event :</h4> </div>
                <div class="col-sm-10">
                    <marquee scrolldelay="180">
                        <p>
                            <p> Recruitment Announcement :- Post: PHP Laravel Developer. Deadline: 28 Febryary 2017</p>
                        </p>
                    </marquee>
                </div>
            </div>

        </div><br>
       <!--end marquee --> 
        
       <!-- start slider -->
       
       <div id="jssor_1" style="position: relative; margin: 0 auto; top: 0px; left: 0px; right: 0px; width: 1300px; height: 600px; overflow: hidden; visibility: hidden;">
      <!-- Loading Screen -->
        <div data-u="loading" style="position: absolute; top: 0px; left: 0px;">
            <div style="filter: alpha(opacity=70); opacity: 0.7; position: absolute; display: block; top: 0px; left: 0px; width: 100%; height: 100%;"></div>
            <div style="position:absolute;display:block;background:url('img/loading.gif') no-repeat center center;top:0px;left:0px;width:100%;height:100%;"></div>
        </div>
        <div data-u="slides" style="cursor: default; position: relative; top: 0px; left: 0px; right: 0px; width: 1270px; height: 600px; overflow: hidden;">
            <div data-p="225.00">
                <img data-u="image" src="images/01.jpg" />
                
            </div>
            <div data-p="225.00" style="display: none;">
                <img data-u="image" src="images/05.jpg" />
            </div>
            <div data-p="225.00" data-po="80% 55%" style="display: none;">
                <img data-u="image" src="images/04.jpg" />
            </div>
            <a data-u="any" href="http://www.jssor.com" style="display:none">Full Width Slider</a>
        </div>
        <!-- Bullet Navigator -->
        <div data-u="navigator" class="jssorb05" style="bottom:16px;right:16px;" data-autocenter="1">
            <!-- bullet navigator item prototype -->
            <div data-u="prototype" style="width:16px;height:16px;"></div>
        </div>
        <!-- Arrow Navigator -->
        <span data-u="arrowleft" class="jssora22l" style="top:0px;left:8px;width:40px;height:58px;" data-autocenter="2"></span>
        <span data-u="arrowright" class="jssora22r" style="top:0px;right:8px;width:40px;height:58px;" data-autocenter="2"></span>
    
    
        </div>
       <br>
       <!-- #endregion Jssor Slider End -->
       
       <!--  Start chart -->
       <div class="row">
           <center> <p style="font-size:25px; font-weight: bold; color: "> Drafting CV Statistics</p></center>
           <div class="col-md-12">
               <script type="text/javascript">
window.onload = function () {
	var chart = new CanvasJS.Chart("chartContainer",
	{
		zoomEnabled: true,
		panEnabled: true, 
		title:{
			text: "" 
		},
		legend: {
			horizontalAlign: "right",
			verticalAlign: "center"        
		},
		axisY:{
			includeZero: false
		},
		data: data,  // random generator below
    });
	chart.render();
}

	var limit = 1000;    //increase number of dataPoints by increasing this

	var y = 0;
	var data = []; var dataSeries = { type: "line" };
	var dataPoints = [];
	for (var i = 0; i < limit; i += 1) {
		y += (Math.random() * 10 - 5);
		dataPoints.push({
			x: i - limit / 2,
			y: y                
		});
	}
	dataSeries.dataPoints = dataPoints;
	data.push(dataSeries);   
	
</script>
<script type="text/javascript" src="js/canvasjs.min.js"></script>

<div id="chartContainer" style="height: 350px; width: 100%;">
</div>
           </div>
       </div>
       <!-- end chart -->
       <br>
<!--       <script type="text/javascript">
	window.onload = function () {

		var dps = []; // dataPoints

		var chart = new CanvasJS.Chart("chartContainer",{
			title :{
				text: "Live Random Data"
			},			
			data: [{
				type: "line",
				dataPoints: dps 
			}]
		});

		var xVal = 0;
		var yVal = 100;	
		var updateInterval = 100;
		var dataLength = 500; // number of dataPoints visible at any point

		var updateChart = function (count) {
			count = count || 1;
			// count is number of times loop runs to generate random dataPoints.
			
			for (var j = 0; j < count; j++) {	
				yVal = yVal +  Math.round(5 + Math.random() *(-5-5));
				dps.push({
					x: xVal,
					y: yVal
				});
				xVal++;
			};
			if (dps.length > dataLength)
			{
				dps.shift();				
			}
			
			chart.render();		

		};

		// generates first set of dataPoints
		updateChart(dataLength); 

		// update chart after specified time. 
		setInterval(function(){updateChart()}, updateInterval); 

	}
	</script>
	<div id="chartContainer" style="height: 300px; width:100%;">
	</div>-->
       
       
       <!-- insert Modal Start -->
<div id="add_user" class="modal fade" role="dialog">
    <div class="modal-dialog modal-lg">
       <?php echo Form::open(array('method'=>'post','id'=>'save','files'=>'true')); ?>

        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>    
            </div>
            
            <div class="modal-body" >
                <table class="table table-hover" id="view_user">
    
    <tr>
        <th>Full Name</th>
        
        <td><?php echo Form::text('appl_name','',array(
    'class'=>'form-control',
    'id'=>'appl_name',
    'placeholder'=>'enter your Full Name',
    'onkeyup'=>'formValidation(id)',
    'onchange'=>'formValidation(id)'
            
            )); ?></td>
       
          <th>Father Name</th>
        
        <td><?php echo Form::text('father_name','',array(
    'class'=>'form-control',
    'id'=>'father_name',
    'placeholder'=>'enter your Father Name',
    'onkeyup'=>'formValidation(id)',
    'onchange'=>'formValidation(id)'
            
            )); ?></td>
        
    </tr>
    <tr><td></td><td id="appl_name_error" style="color:red"></td><td></td><td id="father_name_error" style="color:red"></td></tr>
    
   
    
    <tr>
        <th>Mother Name</th>
        
        <td><?php echo Form::text('mother_name','',array(
    'class'=>'form-control',
    'id'=>'mother_name',
    'placeholder'=>'enter your Mother Name',
    'onkeyup'=>'formValidation(id)',
    'onchange'=>'formValidation(id)'
            
            )); ?></td>
    
        <th>Gender</th>
         <td><?php echo Form::radio('gender','Male',array(
    'class'=>'form-control',
    'id'=>'male',
    'onkeyup'=>'formValidation(id)',
    'onchange'=>'formValidation(id)'
            
            )); ?>Male
         
    
        <?php echo Form::radio('gender','Female',array(
    'class'=>'form-control',
    'id'=>'female',
    'onkeyup'=>'formValidation(id)',
    'onchange'=>'formValidation(id)'
            
            )); ?>Female
         </td>
         
    </tr>
    <tr> <td></td><td id="mother_name_error" style="color:red"></td><td></td></tr>
    
    
   
    <tr> <th>Parmanent Address</th>
        <td><?php echo Form::textarea('parmanent_address','',array(
    'class'=>'form-control ',
    'id'=>'parmanent_address',
    'placeholder'=>'enter your Parmanent Address',
    'onkeyup'=>'formValidation(id)',
    'style'=>'height:60px',
    'onchange'=>'formValidation(id)'
            
            )); ?></td>
    <th>Present Address</th>
        <td><?php echo Form::textarea('present_address','',array(
    'class'=>'form-control',
    'id'=>'present_address',
    'placeholder'=>'enter your Present Address',
    'style'=>'height:60px',
    'onkeyup'=>'formValidation(id)',
    'onchange'=>'formValidation(id)'
            
            )); ?></td>
    </tr>
    <tr><td></td> <td id="parmanent_address_error" style="color:red"></td><td></td><td id="present_address_error" style="color:red"></td></tr>
    
     
    
      <tr> <th>Date of Birth</th>
        <td><?php echo Form::text('birthday','',array(
    'class'=>'form-control',
    'placeholder'=>'enter your Date of Birth',
    'id'=>'datepicker',
    'onkeyup'=>'formValidation(id)',
    'onchange'=>'formValidation(id)'
            
            )); ?></td>
      <th>Education</th>
        <td><?php echo Form::select('education',array('MBA'=>'MBA','BBA'=>'BBA','MSC'=>'MSC','BSC'=>'BSC','Others'=>'Others'),null,['class'=>'form-control','id'=>'education','onkeyup'=>'formValidation(id)','onchange'=>'formValidation(id)']); ?></td>
    
      </tr>
    <tr><td></td> <td id="birthday_error" style="color:red"></td><td></td> <td id="education_error" style="color:red"></td></tr>
    
    
    
    <tr>
        <th>Religion</th>
        <td><?php echo Form::select('relegion',['Islam'=>'Islam','Hindhu'=>'Hindhu','Others'=>'Others'],'null',array(
    'class'=>'form-control',
    'id'=>'relegion',
    'onkeyup'=>'formValidation(id)',
    'onchange'=>'formValidation(id)'
            
            )); ?></td>
    <th>Nationality</th>
        <td><?php echo Form::text('nationality','',array(
    'class'=>'form-control',
    'id'=>'nationality',
    'placeholder'=>'enter your Nationality',
    'onkeyup'=>'formValidation(id)',
    'onchange'=>'formValidation(id)'
            
            )); ?></td>
    </tr>
    <tr><td></td> <td id="relegion_error" style="color:red"></td><td></td> <td id="nationality_error" style="color:red"></td></tr>
    
    
    
    
    <tr>
        <th>National ID</th>
        <td><?php echo Form::text('nid','',array(
    'class'=>'form-control',
    'id'=>'nid',
    'placeholder'=>'enter your National ID Number',
    'onkeyup'=>'formValidation(id)',
    'onchange'=>'formValidation(id)'
            
            )); ?></td>
        <th>Handicape</th>
        <td><?php echo Form::select('handicape',['Yes'=>'Yes','No'=>'No'],'null',array(
    'class'=>'form-control',
    
    'id'=>'handicape',
    'onkeyup'=>'formValidation(id)',
    'onchange'=>'formValidation(id)'
            
            )); ?></td>
    </tr>
    <tr><td></td> <td id="nid_error" style="color:red"></td><td></td> <td id="handicape_error" style="color:red"></td></tr>
              
    
    
    <tr> <th>Email</th>
        <td><?php echo Form::text('email','',array(
    'class'=>'form-control',
    'id'=>'email',
    'placeholder'=>'enter your email',
    'onkeyup'=>'formValidation(id)',
    'onchange'=>'formValidation(id)',
    
            
            )); ?></td>
    <th>Contact Number</th>
        <td><?php echo Form::text('phone','',array(
    'class'=>'form-control',
    'id'=>'phone',
    'placeholder'=>'enter your Contact Number',
    'onkeyup'=>'formValidation(id)',
    'onchange'=>'formValidation(id)'
            
            )); ?></td>
    </tr>
    <tr><td></td> <td id="email_error" style="color:red"></td><td></td> <td id="phone_error" style="color:red"></td></tr>
    
    <tr><th>Image Upload</th>
    
        <td><?php echo Form::file('image'); ?></td>
    </tr>
                </table>
            </div>
            
             <div class="modal-footer">
                 <?php echo Form::reset('Reset',['class'=>'btn btn-primary','id'=>'configreset']); ?>

               <?php echo Form::button('submit',array('class'=>'btn btn-success btn-sm','onclick'=>'save_data()')); ?>

                
               <?php echo Form::button('Cancel',array('class'=>'btn btn-danger btn-sm','data-dismiss'=>'modal')); ?>

               
<!--               <buttonn type="button" class="btn btn-sm btn-success" data-dismiss="modal">No</button>-->
            </div>
            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
        <?php echo Form::close(); ?>

        </div>
    </div>
</div>
<!-- insert Modal End-->
    </div>

            <div class="row" style="background-color: #DAF7A6 ; padding: 40px; ">
<div class="col-sm-3 text-left">
    <p>Copyright(@)<a href="#">RASEL AHSAN</a></p>

</div>
                <div class="col-sm-3 text-center">
                    
                    <a href="#">contact</a> <a href="#">about us</a>
                    <p><i class="material-icons">01916580472</i><br>raselahsan414@gmail.com</p>
                </div>
                <div class="col-sm-6 text-right" style="margin-top: -20px;">
                    <a href="https://www.facebook.com/rasel.ahsan2" class="btn btn-social-icon btn-facebook">
<span class="fa fa-facebook"></span>

</a>
<a class="btn btn-social-icon btn-twitter">
<span class="fa fa-twitter"></span>

</a>

<a class="btn btn-social-icon btn-danger">
<span class="fa fa-youtube"></span>

</a>
<a class="btn btn-social-icon btn-linkedin">
<span class="fa fa-linkedin"></span>

</a>
                    </a>
<a class="btn btn-social-icon btn-instagram">
<span class="fa fa-instagram"></span>

</a>

                    <a class="btn btn-social-icon btn-yahoo">
<span class="fa fa-yahoo"></span>

</a>
                </div><br>

</div>   
<!--     <a id="back-to-top" href="#" class="btn btn-primary btn-lg back-to-top" role="button" title="Click to return on the top page" data-toggle="tooltip" data-placement="left"><span class="glyphicon glyphicon-chevron-up"></span></a>
     -->
     
<a href="#" class="back-to-top" style="display: inline; ">
 
<i class="fa fa-arrow-circle-up"></i>
 
</a>
</body>

<script>
    window.Laravel = <?php echo json_encode([
        'csrfToken' => csrf_token(),
    ]); ?>
        
        $('#configreset').click(function(){
            $('#save')[0].reset();
 });
</script>


  
  <script>
function save_data(){
    var form=$('#save').get(0);
 
  var appl_name=$('input[name=appl_name]').val();
    var father_name=$('input[name=father_name]').val();
    var mother_name=$('input[name=mother_name]').val();
    var gender=$('radio[name=gender]').val();
    var parmanent_address=$('input[name=parmanent_address]').val();
   var present_address=$('input[name=present_address]').val();
    var birthday=$('input[name=birthday]').val();
    var education=$('select[name=education]').val();
    var relegion=$('select[name=relegion]').val();
    var nationality=$('input[name=nationality]').val();
    var nid=$('input[name=nid]').val();
    var handicape=$('select[name=handicape]').val();
    var phone=$('input[name=phone]').val();
    var email=$('input[name=email]').val();
    var appl_picture=$('input[name=image]').val();
    
        var token=$('input[name=_token]').val();
    
    if(appl_name===""|| father_name===""|| mother_name===""|| parmanent_address===""|| present_address===""|| birthday===""|| education===""|| relegion===""|| nationality===""|| nid===""|| handicape===""|| phone===""|| email===""){
         if(appl_name===""){
        $('#appl_name_error').html("Please Enter Your Full Name");
        $('#appl_name').css('border-color','red');
    }
        
        if(father_name===""){
        $('#father_name_error').html("Please Enter Your Father Name");
        $('#father_name').css('border-color','red');
    }
    
        if(mother_name===""){
        $('#mother_name_error').html("Please Enter Your Mother Name");
        $('#mother_name').css('border-color','red');
    }
    
     if(parmanent_address===""){
        $('#parmanent_address_error').html("Please Enter your Parmanent Address");
        $('#parmanent_address').css('border-color','red');
    }
    
    if(present_address===""){
        $('#present_address_error').html("Please Enter Present Address");
        $('#present_address').css('border-color','red');
    }
    
    if(birthday===""){
        $('#birthday_error').html("Please Enter Your Date of Birth");
        $('#birthday').css('border-color','red');
    }
        
        if(education===""){
        $('#education_error').html("Please Select Your Degree");
        $('#education').css('border-color','red');
    }
    
        if(relegion===""){
        $('#relegion_error').html("Please select your Relegion");
        $('#relegion').css('border-color','red');
    }
    
     if(nationality===""){
        $('#nationality_error').html("Please Enter your Nationality");
        $('#nationality').css('border-color','red');
    }
    
    if(nid===""){
        $('#nid_error').html("Please input your NID");
        $('#nid').css('border-color','red');
    }
    
      if(handicape===""){
        $('#handicape_error').html("Please Select Your Status");
        $('#handicape').css('border-color','red');
    }
    
        if(phone===""){
        $('#phone_error').html("Please input your Phone Number");
        $('#phone').css('border-color','red');
    }
    
     if(email===""){
        $('#email_error').html("Please Enter your email");
        $('#email').css('border-color','red');
    }
    
    
    }else{
       $.ajax({
          
           url:'infinity_save_data',
           method:'post',

               data: new FormData(form),
            processData:false,
            contentType:false,
           success: function(){
                $('#add_user').modal('hide');
               window.location.assign('<?php  redirect('template');?>');

           }
       }); 
    }   
}
</script>
<script>
function formValidation(id){
    var val=$.trim($('#'+id).val());
    if(val===''){
        $('#'+id+'_error').html('');
        $('#'+id).css('border-color','red');
        
    }else{
        $('#'+id+'_error').html('');
        $('#'+id).css('border-color','green');
        }
    }
    </script>
</html>