<html>
    <head>
        <title>Report</title>
    </head>
    <body>
        <script>
function hide(){
    document.getElementById('pr').style.display="none";
    
}
</script>

<div id="pr">  
    <a href="allotment_price_installment"><img src="images/back.png"></a>
<a href="Javascript:void(0)" onclick="hide();window.print"><img src="images/print.png"></a>
<a href="word_report"><img src="images/word.png"></a>
<a href="excel_report"><img src="images/excel.png"></a>
<a href="pdf_report"><img src="images/pdf.png"></a>

</div>
        
        
        <table class="table table-bordered" width="100%" border="1">
    
<thead>
<tr>
<th>Sl</th>
<th>Client Name</th>
<th>Flat Type</th>
<th>Total Amount</th>
<th>Project Name</th>
<th>Category</th>
<th>Area</th>
</tr>
</thead>

<?php echo e($i=1); ?>

<?php $__currentLoopData = $query; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
<tr>
<td><?php echo e($i++); ?></td>
<td><?php echo e($row->Client_Name); ?></td>
<td><?php echo e($row->Flat_Type); ?></td>
<td><?php echo e($row->Total_Amount); ?></td>
<td><?php echo e($row->P_Name); ?></td>
<td><?php echo e($row->P_Category); ?></td>
<td><?php echo e($row->P_Area); ?></td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
</table>
    </body>
</html>


