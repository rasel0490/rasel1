<?php echo Html::style('/css/bootstrap.min.css'); ?>

<?php echo Html::style('/css/datatables.css'); ?>

<?php echo Html::script('/js/jquery-1.11.3.min.js'); ?>

<?php echo Html::script('/js/bootstrap.min.js'); ?>

<?php echo Html::script('/js/jquery.mobile-1.4.5.js'); ?>

<?php echo Html::script('/js/jquery-migrate-3.0.0.min.js'); ?>

<?php echo Html::script('/js/datatables.js'); ?>

<?php echo Form::open(array('method'=>'post','id'=>'save','url'=>'check_login')); ?>

<body style="background-color: #81e5f5"  oncontextmenu="return false" >

    <a style="float:left; margin:10px 0px 0px 0px;" href="template" class="" ><img class="img-responsive" src="images/back-icon.png" alt="back"></a>
<center style="margin-top: 40px; font-size: 20px;font-weight: bold">Infinity technology International Ltd
<h4 style="font-weight: bold" align="center">Mirpur DOHS Dhaka</h4>
    <h5 style="font-weight: bold" align="center">Cell: 01916580472</h5>
</center>
<table class=" form-login" style="width: 23%; height: 50%; margin-top: 10px; background-color: #436c72" align="center">
    <tr>
        <th style="color: whitesmoke">Username</th>
        <td><?php echo Form::text('username','',['class'=>'form-control input-sm autofocus','placeholder'=>'enter your username','id'=>'user_name']); ?></td>
        
    </tr>
    
    <tr><td></td> <td><?php echo e($errors->first('username')); ?></td></tr>
       
       
    
    <tr>
        <th style="color: whitesmoke">Email</th>
        <td><?php echo Form::text('email','',['class'=>'form-control input-sm autofocus','placeholder'=>'enter your email','id'=>'user_email']); ?></td>
        
    </tr>
    <tr>
    <td></td><td><?php echo e($errors->first('email')); ?></td>
    </tr>
    <tr>
        <th style="color: whitesmoke">Password</th>
         <td><?php echo Form::password('password',['class'=>'form-control input-sm autofocus','placeholder'=>'enter your password','id'=>'user_pass']); ?></td>
    </tr>
      <tr>
       
       <td></td> <td><?php echo e($errors->first('password')); ?></td>
    </tr>
    <tr>
                    <td style="color: whitesmoke">
                        <input type="checkbox" value="remember-me"> Remember me
                    </td>
               </tr>
    <tr>
        <th></th>
       <td> <?php echo Form::submit('Login',['class'=>'btn btn-lg btn-primary btn-block btn-signin ','id'=>'']); ?> </td>
    </tr>
<!--    <?php echo Form::reset('Reset',['class'=>'btn btn-danger','id'=>'configreset']); ?>

    <td><?php echo Form::submit('sing in',['class'=>'btn btn-lg btn-primary btn-block btn-signin','id'=>'']); ?></td>-->
<tr>
    <td></td>  <td>
                         <a href="#" class="forgot-password">
                Forgot the password?
            </a>
                    </td>
               </tr>
</table>
<?php echo Form::Close(); ?>

<center>All copyright reserved (@) infinity IT te@m</center>
</body>



<script language="javascript">
  document.onmousedown = disableclick;
  status = "Right Click Disabled";
  Function disableclick(e)
  {
    if(event.button == 2)
    {
      alert(status);
      return false; 
    }
  }
</script>

<script>
window.onload = function() {
 var myuser = document.getElementById('user_name');
 var myemail = document.getElementById('user_email');
 var mypass = document.getElementById('user_pass');
 myuser.onpaste = function(e) {
   e.preventDefault();
 }
 
 myemail.onpaste = function(e) {
   e.preventDefault();
 }
 
 mypass.onpaste=function(e){
  e.preventDefault();   
 }
 
 
}

$('#configreset').click(function(){
            $('#save')[0].reset();
 });
</script>