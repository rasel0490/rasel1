<?php if(!$abc=Session::get('sess_user_name')): ?>
<script type="text/javascript">
    window.location = "<?php echo e(url('login')); ?>";//here double curly bracket
</script>
<?php echo e($abc); ?>

<?php endif; ?>
<?php echo Html::style('/css/bootstrap.min.css'); ?>

<?php echo Html::style('/css/datatables.css'); ?>

<?php echo Html::style('/css/jquery-ui.css'); ?>

<?php echo Html::script('/js/jquery-1.11.3.min.js'); ?>

<?php echo Html::script('/js/bootstrap.min.js'); ?>

<?php echo Html::script('/js/jquery-ui.js'); ?>

<?php echo Html::script('/js/datatables.js'); ?>

<!--  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">   -->
<style>
    img{
        height: 30px;
        width:30px;
    }
</style>

<script language="javascript">
  document.onmousedown = disableclick;
  status = "Right Click Disabled";
  Function disableclick(e)
  {
    if(event.button == 2)
    {
      alert(status);
      return false; 
    }
  }
</script>

<body style="background-color:#076F91"  oncontextmenu="return false" onLoad="noBack();" onpageshow="if (event.persisted) noBack();" onUnload="" >
   
    
     <p><h1 style="font-weight: bold" align="center">Infinity Technology Int. Ltd.</h1>
    <h3 style="font-weight: bold" align="center">Mirpur DOHS Dhaka</h3>
    <h3 style="font-weight: bold" align="center">Cell: 01916580472</h3>
</p>

<a style="margin-right:10px; float: right " href="logout" class="btn btn-md btn-danger" >Logout</a>
<!--start insert-->
<table class="table table-hover example mytable" width="100%">
<?php echo e($i=1); ?>

<thead>
<tr>
<th>Sl</th>
<th>Applicant Name</th>
<th>Father Name</th>
<th>Mother Name</th>
<th>Gender</th>
<th>Date of Birth</th>
<th>Education</th>
<th>Phone No</th>
<th>Email</th>
<th>Image</th>

<th>Print</th>
</tr>
</thead>
<?php $__currentLoopData = $query; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
<tr>
<td><?php echo e($i++); ?></td>
<td><?php echo e($row->appl_name); ?></td>
<td><?php echo e($row->father_name); ?></td>
<td><?php echo e($row->mother_name); ?></td>
<td><?php echo e($row->gender); ?></td>
<td><?php echo e($row->birthday); ?></td>
<td><?php echo e($row->education); ?></td>
<td><?php echo e($row->phone); ?></td>
<td><?php echo e($row->email); ?></td>
<td><?php echo e(Html::image('uploads/'.$row->appl_picture)); ?></td>

<td><?php echo Form::button('Print',array('class'=>'btn btn-info','data-toggle'=>'modal','data-target'=>'#viewD','id'=>$row->cv_id,'onclick'=>"viewDetails(id)")); ?></td>
  <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
</table>





<!-- Modal for view Starts Here -->
<div id="viewD" class="modal fade" role="dialog">
    <div class="modal-dialog modal-lg">

        <!-- Modal content-->
       
<!--        <form id="update_c"  method="post" enctype="multipart/form-data">-->
 <?php //echo form_open_multipart('home/updateleftmenuse');?>
        <div class="modal-content" style="">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <strong>print preview Resume</strong>
            </div>
            <div class="modal-body" id="table_body"  style="background-color:">
                
                <div id="mr_view_data"></div>
            </div>
            <div class="modal-footer">
        </div>
        </div>
     
        
    </div>
</div>
<!-- Modal for view Ends Here -->

</body>
<script>
    window.Laravel = <?php echo json_encode([
        'csrfToken' => csrf_token(),
    ]); ?>
</script>

<script type="text/javascript">
        window.history.forward();
        function noBack()
        {
            window.history.forward();
        }
</script>

<script>
$(document).ready(function(){
    
 $('.example').dataTable();   
    
});

</script>
<!--<script type="text/javascript">
    $(function() {
      
      
      $("#datepicker").datepicker({
        dateFormat: 'yy-mm-dd'
      });
      
    });
  </script>-->
  
   

<script>
    function viewDetails(idb){
         var token=$('input[name=_token]').val();
       
                
                $.ajax({
                url: 'infinity_view_data',
                method: 'post',
                data: {id:idb,_token:token},
                success: function (data) {
                    $('#mr_view_data').html(data);
                }
        });
        
    }
</script>

