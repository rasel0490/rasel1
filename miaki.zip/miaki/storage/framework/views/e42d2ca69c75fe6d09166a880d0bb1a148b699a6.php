<?php echo Html::style('/css/bootstrap.min.css'); ?>

<?php echo Html::style('/css/datatables.css'); ?>

<?php echo Html::script('/js/jquery-1.12.3.min.js'); ?>

<?php echo Html::script('/js/bootstrap.min.js'); ?>

<?php echo Html::script('/js/datatables.js'); ?>

<style>
    img{
        height: 70px;
        width:70px;
    }
</style>
<h1 align="center">East West Property Development (Pvt.) Ltd.</h1>
<h2 align="center"> Dhanmondi,Dhaka</h2>
<script>
function hide(){
    document.getElementById('pr').style.display="none";
    
}
</script>
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
   <div id="pr">
    <a href="client_info" class="btn btn-large btn-primary">Back</button> 
<a href="Javascript:void(0)" class="btn btn-success" onclick="hide();window.print">Print Preview</a>
<a href="word_user" class="btn btn-success" onclick="hide();window.print">Word</a>
<a href="excel_user" class="btn btn-success" onclick="hide();window.print">Excel</a>
<a href="pdf_user" class="btn btn-success">Pdf</a>
    </div>

<table class="table table-hover example mytable" width="100%" border="1">
 <thead>
<tr>
<th>Sl</th>
<th>Client Name</th>
<th>Client Address</th>
<th>Client Phone</th>
<th>Client Email</th>
<th>Picture</th>

</tr>
</thead>
<?php echo e($i=1); ?>

<?php $__currentLoopData = $query; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
<tr>
<td><?php echo e($i++); ?></td>
<td><?php echo e($row->Client_Name); ?></td>
<td><?php echo e($row->Client_Address); ?></td>
<td><?php echo e($row->Client_Phone); ?></td>
<td><?php echo e($row->Client_Email); ?></td>
<td><?php echo e(HTML::image('uploads/'.$row->Client_Picture)); ?></td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
</table>