<!--<?php if(!$abc=Session::get('sess_user_name')): ?>
<script type="text/javascript">
    window.location = "<?php echo e(url('login')); ?>";
</script>
<?php echo e($abc); ?>

<?php endif; ?>-->

<?php echo Html::style('/css/bootstrap.min.css'); ?>

<?php echo Html::style('/css/datatables.css'); ?>

<?php echo Html::script('/js/jquery-1.12.3.min.js'); ?>

<?php echo Html::script('/js/datatables.js'); ?>

<?php echo Html::script('/js/bootstrap.js'); ?>

<?php echo Html::script('/js/bootstrap.min.js'); ?>

<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

<body>
    <a style="margin: 40px 0px 10px 0px; " href="template" class="btn btn-md btn-default" >Home</a>
    <a href="alltoment_print" class="btn btn-success" style="margin-top:40px">Print</a>
    <a href="<?php echo e(URL::to('logout')); ?>" class="btn btn-danger" style="margin-top:40px">Logout</a>
<button data-toggle="modal" data-target="#add" class="btn btn-primary" style="margin-top:40px">Add User</button>
<div id="add" class="modal fade" role="dialog">
    <div class="modal-dialog modal-lg">
<!--        <form id="save" method="post" enctype="">-->
<!--            <?php echo Form::open(['route'=>'mycount1.store','method'=>'post','id'=>'save']); ?>-->
<?php echo Form::open(array('method'=>'post','id'=>'save')); ?>

            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>                    
                </div>
                <div class="modal-body">
                    <table class="table table-hover" id='view_tbl'>
    
    <tr>
        <th>Sale</th>
        <td>
            <?php echo Form::text('sale','',array(
            'class'=>'form-control',
            'id'=>'sale',
            'onchange'=>'names(id)',
            'onkeyup'=>'names(id)'
            )); ?>            
        </td>     
    </tr>
    <tr>
        <td></td> 
        <td id="sale_error" style="color:red"></td>
    </tr>
    <tr>
        <th>Not Sale</th>
        <td>
            <?php echo Form::text('not_sale','',array(
            'class'=>'form-control',
            'id'=>'not_sale',
            'onchange'=>'names(id)',
            'onkeyup'=>'names(id)'
            )); ?>            
        </td>        
    </tr>
    <tr>
        <td></td> 
        <td id="not_sale_error" style="color:red"></td>
    </tr>
    <tr>
        <th>Flat Type</th>
        <td>
            <?php echo Form::text('flat_type','',array(
            'class'=>'form-control',
            'id'=>'flat_type',
            'onchange'=>'names(id)',
            'onkeyup'=>'names(id)'
            )); ?>            
        </td>        
    </tr>
    <tr>
        <td></td> 
        <td id="flat_type_error" style="color:red"></td>
    </tr>    
</table>
                </div>
                <div class="modal-footer">
                <?php echo Form::button('save',array('class'=>'btn btn-success btn-sm','onclick'=>'save_data()')); ?>                
               <?php echo Form::button('Cancel',array('class'=>'btn btn-danger btn-sm','data-dismiss'=>'modal')); ?>

                </div>
                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                <?php echo Form::close(); ?>

            </div>        
    </div>
</div>
    
<!--<a href="form1" class="btn btn-success">Add User</a>-->
<table class="table table-bordered example mytable" width="100%">
    <div id="table_body">
<thead>
<tr>
<th>Sl</th>
<th>Sale</th>
<th>Not Sale</th>
<th>Flat Type</th>
<th>Delete</th>
<th>Update</th>
<th>View</th>

</tr>
</thead>

<?php echo e($i=1); ?>

<?php $__currentLoopData = $query; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
<tr>
<td><?php echo e($i++); ?></td>
<td><?php echo e($row->Sale); ?></td>
<td><?php echo e($row->Not_Sale); ?></td>
<td><?php echo e($row->Flat_Type); ?></td>
<td><?php echo Form::button('Delete',array('class'=>'btn btn-danger','data-toggle'=>'modal','data-target'=>'#delete_nc','id'=>$row->Allotment_Status_ID)); ?></td>
<td><?php echo Form::button('Edit',array('class'=>'btn btn-info','data-toggle'=>'modal','data-target'=>'#update_nc','id'=>$row->Allotment_Status_ID,'onclick'=>"updateUserForm(id)")); ?></td>
<td><?php echo Form::button('View',array('class'=>'btn btn-success','data-toggle'=>'modal','data-target'=>'#viewD','id'=>$row->Allotment_Status_ID,'onclick'=>"viewDetails(id)")); ?></td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
</table>
</div>


<div id="delete_nc" class="modal fade" role="dialog">
<div class="modal-dialog modal-md">
<div class="modal-content">
<div class="modal-header">
<button type="button" class="close" data-dismiss="modal">&times;</button>
<img src="images/warning.jpg" height="50px" width="50px"/><strong style="color:red">Warning!</strong>
</div>
<div class="modal-body">
    <input type="hidden" id="pre_id" value=""/>
Do you want to delete data?
</div>
<div class="modal-footer">
<button class="btn btn-sm btn-danger" id="delete">Yes</button>
<button type="button" class="btn btn-sm btn-success" data-dismiss="modal">No</button>
</div>
</div>
</div>
</div>



<div id="update_nc" class="modal fade" role="dialog">
<div class="modal-dialog modal-md">
    <?php echo Form::open(array('method'=>'post','id'=>'update_c')); ?>

<div class="modal-content">
<div class="modal-header">
<button type="button" class="close" data-dismiss="modal">&times;</button>
<strong>Update Allotment Status</strong>
</div>
<div class="modal-body" id="table_body">    
    <div id="up"></div>
</div>
<div class="modal-footer">
<input type="button" class="btn btn-sm btn-danger" onclick="updateData()" value="Update">
<button type="button" class="btn btn-sm btn-success" data-dismiss="modal">No</button>
</div>
</div>
<?php echo Form::close(); ?>

</div>
</div>
    
<div id="viewD" class="modal fade" role="dialog">
<div class="modal-dialog modal-md">
<div class="modal-content">
<div class="modal-header">
<button type="button" class="close" data-dismiss="modal">&times;</button>
<strong>View Allotment Status</strong>
</div>
<div class="modal-body" id="table_body">    
    <div id="view_data"></div>
</div>
<div class="modal-footer">
    <button type="button" class="btn btn-sm btn-success" data-dismiss="modal">No</button>
</div>
</div>
</div>
</div>    

</body>
<script>
    window.Laravel = <?php echo json_encode([
        'csrfToken' => csrf_token(),
    ]); ?>
</script>

<script>
    function names(id) {
var val = $.trim($('#' + id).val());
if (val === '') {
$('#' + id + '_error').html('');
$('#' + id).css('border-color', 'red');
} else {
$('#' + id + '_error').html('');
$('#' + id).css('border-color', 'green');
}
}

$(document).ready(function(){
    
	$('.example').dataTable();
        
});
</script>

<script>
function save_data(){    
    var form=$('#save').get(0);
    //var base_url="<?php echo e(URL::to('/')); ?>";       

            var sale=$('input[name=sale]').val();
            var not_sale=$('input[name=not_sale]').val();
            var flat_type=$('input[name=flat_type]').val();
            var token=$('input[name=_token]').val();

            if(sale===''||not_sale===''||flat_type===''){
                if(sale==''){
                    $('#sale_error').html('Please Enter Sale Status');
                    $('#sale').css("border-color","red");
                }
                if(not_sale==''){
                    $('#not_sale_error').html('Please Enter Sale Status');
                    $('#not_sale').css("border-color","red");
                }
                if(flat_type==''){
                    $('#flat_type_error').html('Please Enter Flat Type');
                    $('#flat_type').css("border-color","red");
                }
            }else{              
                $.ajax({
                    url:'save_data',
                    method:'post',
                    data:{
                        'sale':sale,
                        'not_sale':not_sale,
                        'flat_type':flat_type,
                        '_token':token
                    },
                    dataType:'HTML',                    
                    success:function(data){
                        $('#add').modal('hide');
                                window.location.assign('<?php  redirect('allotoment_status');?>');
                    }
                });
            }
            
    
}

$(document).ready(function(){
        
     $('.mytable').delegate('button','click',function(event){
    var id=event.target.id;  
    $('#pre_id').val(id);    
    });
    
     $('#delete').click(function(){
        var id=$('#pre_id').val();
       var token=$('input[name=_token]').val();
        $.ajax({
            url:'delete_data',
            method:'post',
            data:{id:id,_token:token},
            success: function(){
              window.location.assign('<?php  redirect('allotoment_status');?>');
            }
            
        });
        
    });

        
    });
    
    
    function updateUserForm(ida){
         var token=$('input[name=_token]').val();
                
                $.ajax({
                url: 'edit_form',
                method: 'post',
                data: {id:ida,_token:token},
                success: function (data) {
                    $('#up').html(data);
                }
        });
        
    }
    
    function viewDetails(idb){
         var token=$('input[name=_token]').val();
                
                $.ajax({
                url: 'view_details', 
                method: 'post',
                data: {id:idb,_token:token},
                success: function (data) {
                    $('#view_data').html(data);
                }
        });
        
    }
    
    function updateData(){
        
        var sale=$.trim($('input[name=edit_sale]').val());
        var not_sale=$.trim($('input[name=edit_not_sale]').val());
        var flat_type=$.trim($('input[name=edit_flat_type]').val());
        var token=$('input[name=_token]').val();
    var id=$('input[name=id]').val();
//      alert(id);
            $.ajax({
                url: 'update_data',
                method: 'post',
                  data: {
                      'sale':sale,
                      'not_sale':not_sale,
                      'flat_type':flat_type,
                      '_token':token,
                      'id':id                      
                  },
                  dataType:'HTML',                 
               success: function (data) {                   
                    $('#update_nc').modal('hide');
                    window.location.assign('<?php  redirect('allotoment_status');?>');
                  
                }
            });
    }

</script>