<?php echo Html::style('/css/bootstrap.min.css'); ?>

<?php echo Html::script('/js/jquery-1.11.3.min.js'); ?>

<?php echo Html::script('/js/bootstrap.min.js'); ?>


<!--<?php echo Form::model($query, [
    'method' => 'PATCH',
    'route' => ['mrcont.update', $query->money_id]
]); ?>-->
<table class="table table-hover">
     <?php echo Form::hidden('id',$query->money_id,array('class'=>'form-control','id'=>'id')); ?>

    <tr>
        <th>Client Name</th>
        <td><?php echo Form::text('edit_client_name',$query->client_name,array('class'=>'form-control','id'=>'edit_client_name')); ?></td>
        
        
    </tr>
   
    <tr>
    <th>Flat Type</th>
        <td><?php echo Form::text('edit_flat_type',$query->flat_type,array('class'=>'form-control','id'=>'edit_flat_type')); ?></td>
    </tr>
    
    <tr>
    <th>Payment Type</th>
        <td><?php echo Form::text('edit_payment_type',$query->payment_type,array('class'=>'form-control','id'=>'edit_payment_type')); ?></td>
    </tr>
    
    <tr>
    <th>Monthly Installment</th>
        <td><?php echo Form::text('edit_monthly_installment',$query->monthly_installment,array('class'=>'form-control','id'=>'edit_monthly_installment')); ?></td>
    </tr>
    
     <tr>
    <th>Monthly Rent</th>
        <td><?php echo Form::text('edit_monthly_rent',$query->monthly_rent,array('class'=>'form-control','id'=>'edit_monthly_rent')); ?></td>
    </tr>
    
<!--    <tr>
        <td></td>
        <td><?php echo Form::submit('update',['class'=>'btn btn-info']); ?></td>
    </tr>-->
    
</table>
<!--<?php echo Form::close(); ?>-->