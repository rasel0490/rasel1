<?php echo Html::style('/css/bootstrap.min.css'); ?>

<?php echo Html::script('/js/jquery-1.11.3.min.js'); ?>

<?php echo Html::script('/js/bootstrap.min.js'); ?>

<table class="table table-hover " width="100%">
<!--<?php echo e($i=1); ?>


<tr><th>Sl</th><td><?php echo $i++; ?></td></tr>-->

<tr><th>Client Name</th><td><?php echo $query->client_name; ?></td></tr>
<tr><th>Flat Type</th><td><?php echo $query->flat_type; ?></td></tr>
<tr><th>Payment Type</th><td><?php echo $query->payment_type; ?></td></tr>
<tr><th>Monthly Installment</th><td><?php echo $query->monthly_installment; ?></td></tr>

<th>Monthly Rent</th><td><?php echo $query->monthly_rent; ?></td></tr>

</table>