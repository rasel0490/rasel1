<?php echo Html::style('/css/bootstrap.min.css'); ?>

<?php echo Html::style('/css/datatables.css'); ?>

<?php echo Html::script('/js/jquery-1.12.3.min.js'); ?>

<?php echo Html::script('/js/bootstrap.min.js'); ?>

<?php echo Html::script('/js/datatables.js'); ?>

<script>
function hide(){
    document.getElementById('pr').style.display="none";
    
}
</script>
<h1 align="center">East West Property Development (Pvt.) Ltd.</h1>
<h2 align="center"> Dhanmondi,Dhaka</h2>
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<div id="pr">
    <a href="puser"   class="btn btn-large btn-primary">Back</button> 
<a href="Javascript:void(0)" class="btn btn-success" onclick="hide();window.print">Print</a>
<a href="word_payment" class="btn btn-success" onclick="hide();window.print">Word</a>
<a href="excel_payment" class="btn btn-success" onclick="hide();window.print">Excel</a>
<a href="pdf_payment" class="btn btn-success">Pdf</a>
    </div>

<table class="table table-hover example mytable" border="" width="100%">
 <div id="table_body">
<thead>
<tr>
<th>Sl</th>
<th>Steel Cost</th>
<th>Labour Cost</th>
<th>Employee Cost</th>
<th>Advertising Cost</th>
<th>Other Cost</th>



</tr>
</thead>
 <?php echo e($i=1); ?>

<?php $__currentLoopData = $query; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
<tr>
<td><?php echo e($i++); ?></td>
<td><?php echo e($row->Steel_Cost); ?></td>
<td><?php echo e($row->Labour_Cost); ?></td>
<td><?php echo e($row->Employee_Cost); ?></td>
<td><?php echo e($row->Advertising_Cost); ?></td>
<td><?php echo e($row->Other_Cost); ?></td>

</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>


</table>