<?php echo Html::style('/css/bootstrap.min.css'); ?>


<?php echo Html::script('/js/jquery-1.11.3.min.js'); ?>

<?php echo Html::script('/js/bootstrap.min.js'); ?>


<style>
    img{
        height: 180px;
        width:150px;
    }
</style>

<script>
function hide(){
    document.getElementById('pr').style.display="none";
    
}
</script>

<!--<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">-->


<div id="pr" style="margin:20px 10px 30px 10px">
  
<!--<a style="float:left; margin:20px 10px 30px 10px;" href="infinity" class="" ><img class="img-responsive" src="images/back-icon.png" alt="back"></a>-->
 <a style="float:left; margin:20px 10px 30px 10px;" href="Javascript:void(0)" class="" onclick="hide();window.print"></a>
 <a style="float:left; margin:-10px 10px 30px 10px;" href="infinity_pdf/<?php echo e($query->cv_id); ?>" class="" onclick="window.print"><img style="height:25px; width: 25px;"  class="img-responsive" src="images/PDF.png" alt="pdf"></a>
</div>


<table style="font-weight: bold" class=""  align="center" style="float: right" width="100%">
    <tr>  <caption style="font-size: 34px; color:Green;text-align: center">Resume of <?php echo $query->appl_name; ?></caption></tr>
</table>

<table style="height: 160px; width: 150px;" class="" style="" align="right" width="20%">
   
   
    <tr><td><?php echo e(Html::image('uploads/'.$query->appl_picture)); ?></td></tr>
</table>

<table class="table table-hover " width="100%">
<!--<?php echo e($i=1); ?>


<tr><th>Sl</th><td><?php echo $i++; ?></td></tr>-->


<tr><td>Father Name:</td><td class=""><?php echo $query->father_name; ?></td></tr>
<tr><td>Mother Name:</td><td class=""><?php echo $query->mother_name; ?></td></tr>
<tr><td>Gender:</td><td class=""><?php echo $query->gender; ?></td></tr>
<tr><td>Parmanent Address:</td><td class=""><?php echo $query->parmanent_address; ?></td></tr>
<tr><td>Present Address:</td><td class=""><?php echo $query->present_address; ?></td></tr>
<tr><td>Date of Birth:</td><td class=""><?php echo $query->birthday; ?></td></tr>
<tr><td>Education:</td><td class=""><?php echo $query->education; ?></td></tr>
<tr><td>Religion:</td><td class=""><?php echo $query->relegion; ?></td></tr>
<tr><td>Nationality</td><td class=""><?php echo $query->nationality; ?></td></tr>
<tr><td>National ID<td class=""><?php echo $query->nid; ?></td></tr>
<tr><td>handicape</td><td class=""><?php echo $query->handicape; ?></td></tr>
<tr><td>Phone No</td><td class=""><?php echo $query->phone; ?></td></tr>

<tr><td>Email</td><td class=""><?php echo $query->email; ?></td></tr>

</table>