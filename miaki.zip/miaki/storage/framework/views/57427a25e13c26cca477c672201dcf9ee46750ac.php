<?php echo Html::style('/css/bootstrap.min.css'); ?>

<?php echo Html::style('/css/datatables.css'); ?>

<?php echo Html::script('/js/bootstrap.min.js'); ?>

<?php echo Html::script('/js/datatables.js'); ?>

<?php echo Html::script('/js/jquery-1.11.3.min.js'); ?>


<h1 class="alert alert-success">RealEstate Management System</h1>
<a href="rent_info" class="btn btn-info">Rent Info</a>
<a href="money_recept" class="btn btn-success">Money Recept</a>