<?php echo Html::style('/css/bootstrap.min.css'); ?>

<?php echo Html::style('/css/datatables.css'); ?>

<?php echo Html::script('/js/jquery-1.11.3.min.js'); ?>

<?php echo Html::script('/js/bootstrap.min.js'); ?>

<?php echo Html::script('/js/datatables.js'); ?>

<script>
function hide(){
    document.getElementById('pr').style.display="none";
    
}
</script>
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

 <p><h1 style="font-weight: bold" align="center">Real Estate Management System</h1>
    <h3 style="font-weight: bold" align="center">Rampura Dhaka 1219</h3>
    <h3 style="font-weight: bold" align="center">Cell: 01916580472</h3>
</p>
<div id="pr" style="margin:20px 10px 30px 10px">
  
<a style="float:left; margin:20px 10px 30px 10px;" href="money_recept" class="" ><img class="img-responsive" src="images/back-icon.png" alt="back"></a>
 <a style="float:left; margin:20px 10px 30px 10px;" href="Javascript:void(0)" class="" onclick="hide();window.print"><img class="img-responsive" src="images/icon_print_preview.png" alt="print_preview"></a>
<a style="float:left; margin:20px 10px 30px 10px;" href="money_recept_word" class="" onclick="window.print"><img class="img-responsive" src="images/icon-word.png" alt="word"></a>
<a style="float:left; margin:20px 10px 30px 10px;" href="money_recept_excel" class="" onclick="window.print"><img class="img-responsive" src="images/icon-excel.png" alt="excel"></a>
<a style="float:left; margin:20px 10px 30px 10px;" href="money_recept_pdf" class="" onclick="window.print"><img class="img-responsive" src="images/icon-pdf.png" alt="pdf"></a>
</div>
<table class="table table-hover example mytable" width="100%">
<?php echo e($i=1); ?>

<thead>
<tr>
<th>Sl</th>
<th>Client Name</th>
<th>Flat Type</th>
<th>Payment Type</th>
<th>Monthly Installment</th>
<th>Monthly Rent</th>


</tr>
</thead>
<?php $__currentLoopData = $query; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
<tr>
<td><?php echo e($i++); ?></td>
<td><?php echo e($row->client_name); ?></td>
<td><?php echo e($row->flat_type); ?></td>
<td><?php echo e($row->payment_type); ?></td>
<td><?php echo e($row->monthly_installment); ?></td>
<td><?php echo e($row->monthly_rent); ?></td>

</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
</table>
<br><br>

<div style="text-align: right; font-style: italic; margin-right: 30px">Document created by Rasel Ahsan</div>