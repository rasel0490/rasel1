<?php echo Html::style('/css/bootstrap.min.css'); ?>

<?php echo Html::style('/css/datatables.css'); ?>

<?php echo Html::script('/js/jquery-1.12.3.min.js'); ?>

<?php echo Html::script('/js/bootstrap.min.js'); ?>

<?php echo Html::script('/js/datatables.js'); ?>


<script>
function hide(){
    document.getElementById('pr').style.display="none";
    
}
</script>
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
   <div id="pr">
    <a href="report_print"   class="btn btn-large btn-primary">Back</button> 
<a href="report_print" class="btn btn-success" onclick="hide();window.print">Print</a>
<a href="report_word" class="btn btn-success" onclick="hide();window.print">Word</a>
<a href="report_excel" class="btn btn-success" onclick="hide();window.print">Excel</a>
<a href="report_pdf" class="btn btn-success">Pdf</a>
    </div>

<html>
    <head></head>
    <title></title>
    <body>
<table class="table table-hover" width="100%" border="1">
 <thead>
<tr>
<th>Sl</th>
<th>Client Name</th>
<th>Client Address</th>
<th>Client Phone</th>
<th>Client Email</th>
<th>Project Name</th>
<th>Project Area</th>

</tr>
</thead>
<?php echo e($i=1); ?>

<?php $__currentLoopData = $query; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
<tr>
<td><?php echo e($i++); ?></td>
<td><?php echo e($row->Client_Name); ?></td>
<td><?php echo e($row->Client_Address); ?></td>
<td><?php echo e($row->Client_Phone); ?></td>
<td><?php echo e($row->Client_Email); ?></td>
<td><?php echo e($row->P_Name); ?></td>
<td><?php echo e($row->P_Area); ?></td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
</table>
    </body>
</html>



