<?php echo Html::style('/css/bootstrap.min.css'); ?>

<script>
function hide(){
    document.getElementById('pr').style.display="none";
    
}
</script>

<div id="pr">    
<a href="Javascript:void(0)" onclick="hide();window.print"><img src="images/print.png"></a>
<a href="alltoment_word"><img src="images/word.png"></a>
<a href="alltoment_excel"><img src="images/excel.png"></a>
<a href="alltoment_pdf"><img src="images/pdf.png"></a>
</div>

<div id="table_body">
<table class="table table-bordered example mytable" width="100%">
    
<thead>
<tr>
<th>Sl</th>
<th>Sale</th>
<th>Not Sale</th>
<th>Flat Type</th>
</tr>
</thead>

<?php echo e($i=1); ?>

<?php $__currentLoopData = $query; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
<tr>
<td><?php echo e($i++); ?></td>
<td><?php echo e($row->Sale); ?></td>
<td><?php echo e($row->Not_Sale); ?></td>
<td><?php echo e($row->Flat_Type); ?></td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
</table>
</div>
