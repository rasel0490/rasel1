<?php echo Html::style('/css/bootstrap.min.css'); ?>


<?php echo Html::script('/js/jquery-1.12.3.min.js'); ?>

<?php echo Html::script('/js/bootstrap.min.js'); ?>

<h1 align="center">East West Property Development (Pvt.) Ltd.</h1>
<h2 align="center"> Dhanmondi,Dhaka</h2>
<table class="table table-hover">
    
    <tr>
        
        <th>Steel Cost</th>
        <td><?php echo $query->Steel_Cost; ?></td>
    </tr>
    
    <tr>
        <th>Labour Cost</th>
        <td><?php echo $query->Labour_Cost; ?></td>
        
    </tr>
    <tr>
        <th>Employee Cost</th>
        <td><?php echo $query->Employee_Cost; ?></td>
        
    </tr>
     <tr>
        <th>Advertising Cost</th>
        <td><?php echo $query->Advertising_Cost; ?></td>
        
    </tr>
    
     <tr>
        <th>Other Cost</th>
        <td><?php echo $query->Other_Cost; ?></td>
        
    </tr>
    
  
    
</table>

