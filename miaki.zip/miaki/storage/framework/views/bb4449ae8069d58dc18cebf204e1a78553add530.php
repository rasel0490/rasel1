<html>
    <head></head>
    <title></title>
    <body>
<table class="table table-hover" width="100%" border="1">
 <thead>
<tr>
<th>Sl</th>
<th>Client Name</th>
<th>Client Address</th>
<th>Client Phone</th>
<th>Client Email</th>
<th>Project Name</th>
<th>Project Area</th>

</tr>
</thead>
<?php echo e($i=1); ?>

<?php $__currentLoopData = $query; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
<tr>
<td><?php echo e($i++); ?></td>
<td><?php echo e($row->Client_Name); ?></td>
<td><?php echo e($row->Client_Address); ?></td>
<td><?php echo e($row->Client_Phone); ?></td>
<td><?php echo e($row->Client_Email); ?></td>
<td><?php echo e($row->P_Name); ?></td>
<td><?php echo e($row->P_Area); ?></td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
</table>
    </body>
    </html>
