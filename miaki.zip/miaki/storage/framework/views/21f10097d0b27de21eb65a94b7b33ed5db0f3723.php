
<?php echo Html::style('/css/bootstrap.min.css'); ?>

<?php echo Html::style('/css/datatables.css'); ?>

<?php echo Html::script('/js/jquery-1.11.3.min.js'); ?>

<?php echo Html::script('/js/bootstrap.min.js'); ?>

<?php echo Html::script('/js/datatables.js'); ?>

  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">   

<!--<a href="add_info" class="btn btn-success">Add Info</a>-->
<body style="background-color:#076F91">
   
    <a style="margin-left:20px; width:10%" href="money_recept_print" class="" ><img class="img-responsive" src="images/print_icon.png" alt="print"></a>
     <p><h1 style="font-weight: bold" align="center">Real Estate Management System</h1>
    <h3 style="font-weight: bold" align="center">Rampura Dhaka 1219</h3>
    <h3 style="font-weight: bold" align="center">Cell: 01916580472</h3>
</p>
 <a style="margin-left:10px; " href="template" class="btn btn-md btn-default" >Home</a>
<button style="margin: 10px 0px 10px 0px" data-toggle="modal" data-target="#add_user" class="btn btn-md btn-primary">Add Info</button>
<a style="margin-right:10px; float: right " href="logout" class="btn btn-md btn-danger" >Logout</a>

<div id="add_user" class="modal fade" role="dialog">
    <div class="modal-dialog modal-md">
       <?php echo Form::open(array('method'=>'post','id'=>'save')); ?>

        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>    
            </div>
            
            <div class="modal-body" style="background-color:#5bc0de">
                <table class="table table-hover" id="view_user">
    
    <tr>
        <th>Client Name</th>
        
        
        <td>
          

    <select class="form-control" name="client_name" id="client_name">
    <?php $__currentLoopData = $qinfo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
    <option value="<?php echo e($row->Client_Name); ?>"><?php echo e($row->Client_Name); ?></option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>    
    </select>
          
        </td>
    </tr>
    <tr><td></td> <td id="client_name_error" style="color:red"></td></tr>
    
    <tr>
        <th>Flat Type</th>
        <td><?php echo Form::select('flat_type',array('A'=>'A','B'=>'B','C'=>'C','D'=>'D'),null,['class'=>'form-control','id'=>'flat_type','onkeyup'=>'formValidation(id)','onchange'=>'formValidation(id)']); ?></td>
        
        
    </tr>
    <tr><td></td> <td id="flat_type_error" style="color:red"></td></tr>
    
    <tr>
        <th>Payment Type</th>
        <td><?php echo Form::select('payment_type',['Cash'=>'Cash','Cheque'=>'Cheque','Due'=>'Due'],'null',array(
    'class'=>'form-control',
    'id'=>'payment_type',
    'onkeyup'=>'formValidation(id)',
    'onchange'=>'formValidation(id)'
            
            )); ?></td>
        
        
    </tr>
    <tr><td></td> <td id="payment_type_error" style="color:red"></td></tr>
    
    <tr>
        <th>Monthly Installment</th>
        <td><?php echo Form::text('monthly_installment','',array(
    'class'=>'form-control',
    'id'=>'monthly_installment',
    'onkeyup'=>'formValidation(id)',
    'onchange'=>'formValidation(id)'
            
            )); ?></td>
        
        
    </tr>
    <tr><td></td> <td id="monthly_installment_error" style="color:red"></td></tr>
    
    
    <tr>
        <th>Monthly Rent</th>
        <td><?php echo Form::text('monthly_rent','',array(
    'class'=>'form-control',
    'id'=>'monthly_rent',
    'onkeyup'=>'formValidation(id)',
    'onchange'=>'formValidation(id)'
            
            )); ?></td>
        
    </tr>
    <tr><td></td> <td id="monthly_rent_error" style="color:red"></td></tr>
                </table>
    
            </div>
            
             <div class="modal-footer">
               <?php echo Form::button('save',array('class'=>'btn btn-success btn-sm','onclick'=>'save_data()')); ?>

                
               <?php echo Form::button('Cancel',array('class'=>'btn btn-danger btn-sm','data-dismiss'=>'modal')); ?>

               
<!--               <buttonn type="button" class="btn btn-sm btn-success" data-dismiss="modal">No</button>-->
            </div>
            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
        <?php echo Form::close(); ?>

        </div>
    </div>
</div>
<!--end insert-->

<table class="table table-hover example mytable" width="100%">
<?php echo e($i=1); ?>

<thead>
<tr>
<th>Sl</th>
<th>Client Name</th>
<th>Flat Type</th>
<th>Payment Type</th>
<th>Monthly Installment</th>
<th>Monthly Rent</th>
<th>Delete</th>
<th>Edit</th>
<th>View</th>
</tr>
</thead>
<?php $__currentLoopData = $query; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
<tr>
<td><?php echo e($i++); ?></td>
<td><?php echo e($row->client_name); ?></td>
<td><?php echo e($row->flat_type); ?></td>
<td><?php echo e($row->payment_type); ?></td>
<td><?php echo e($row->monthly_installment); ?></td>
<td><?php echo e($row->monthly_rent); ?></td>

<td>

<?php echo Form::button('Delete',array('class'=>'btn btn-danger','data-toggle'=>'modal','data-target'=>'#delete_nc','id'=>$row->money_id)); ?>

</td>
<td><?php echo Form::button('Edit',array('class'=>'btn btn-info','data-toggle'=>'modal','data-target'=>'#update','id'=>$row->money_id,'onclick'=>"updateUserForm(id)")); ?></td>
<td><?php echo Form::button('View',array('class'=>'btn btn-info','data-toggle'=>'modal','data-target'=>'#viewD','id'=>$row->money_id,'onclick'=>"viewDetails(id)")); ?></td>

<!--<td><a href="<?php echo e(route('mrcont.edit',$row->money_id)); ?>" class="btn btn-info">Edit</a></td>
<td><a href="<?php echo e(route('mrcont.edit',$row->money_id)); ?>" class="btn btn-success">View</a></td>-->
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
</table>
<!--<?php echo Form::close(); ?>-->

<!-- Delete Modal Start -->
<div id="delete_nc" class="modal fade" role="dialog">
    <div class="modal-dialog modal-md">

         Modal content
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <img src="image/warning.png"> <strong style="color: red">WARNING !</strong>
            </div>
            <div class="modal-body"  style="background-color:#5bc0de">
                <input type="hidden" id="pre_id" value="">
                Are you sure you want to delete this record ?<br>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-sm btn-danger" id="delete">Yes</button>
                <button type="button" class="btn btn-sm btn-success" data-dismiss="modal">No</button>
            </div>
        </div>
    </div>
</div>
<!-- Delete Modal End-->

<!-- Modal for update Starts Here -->
<div id="update" class="modal fade" role="dialog">
    <div class="modal-dialog modal-lg">

        <!-- Modal content-->
        <?php echo Form::open(array('method'=>'post','id'=>'update_c')); ?>

  <div class="modal-content" style="">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <strong>Update Money Recept</strong>
            </div>
            <div class="modal-body"  style="background-color:#5bc0de">
                
                <div id="up"></div>
            </div>
            <div class="modal-footer">
                <input type="button" class="btn btn-sm btn-success" onclick="updateData()" value="Update">
        <button type="button" class="btn btn-sm btn-primary" data-dismiss="modal">Cancel</button>
    </div>
        </div>
     
        <?php echo Form::close(); ?>

    </div>
</div>
<!-- Modal for update Ends Here -->
<!-- Modal for view Starts Here -->
<div id="viewD" class="modal fade" role="dialog">
    <div class="modal-dialog modal-lg">

        <!-- Modal content-->
       
<!--        <form id="update_c"  method="post" enctype="multipart/form-data">-->
 <?php //echo form_open_multipart('home/updateleftmenuse');?>
        <div class="modal-content" style="">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <strong>View Money Recept</strong>
            </div>
            <div class="modal-body" id="table_body"  style="background-color:#5bc0de">
                
                <div id="mr_view_data"></div>
            </div>
            <div class="modal-footer">
        </div>
        </div>
     
        
    </div>
</div>
<!-- Modal for view Ends Here -->

</body>
<script>
    window.Laravel = <?php echo json_encode([
        'csrfToken' => csrf_token(),
    ]); ?>
</script>

<script>
function save_data(){
    var form=$('#save').get(0);
  //  var base_url="<?php echo e(URL::to('/')); ?>";
  var client_name=$('select[name=client_name]').val();
    var flat_type=$('select[name=flat_type]').val();
    var payment_type=$('select[name=payment_type]').val();
    var monthly_installment=$('input[name=monthly_installment]').val();
    var monthly_rent=$('input[name=monthly_rent]').val();
    var token=$('input[name=_token]').val();
    
    if(client_name===""|| flat_type===""|| payment_type===""|| monthly_installment===""|| monthly_rent===""){
         if(client_name===""){
        $('#client_name_error').html("Please Enter Your Client Name");
        $('#client_name').css('border-color','red');
    }
        
        if(flat_type===""){
        $('#flat_type_error').html("Please Enter Your User Name");
        $('#flat_type').css('border-color','red');
    }
    
        if(payment_type===""){
        $('#payment_type_error').html("Please Enter Payment Type");
        $('#payment_type').css('border-color','red');
    }
    
     if(monthly_installment===""){
        $('#monthly_installment_error').html("Please Enter Monthly Installment");
        $('#monthly_installment').css('border-color','red');
    }
    
    if(monthly_rent===""){
        $('#monthly_rent_error').html("Please Enter Monthly Rent");
        $('#monthly_rent').css('border-color','red');
    }
    }else{
       $.ajax({
          
           url:'save_data',
           method:'post',
           data:{
               'client_name':client_name,
               'flat_type':flat_type,
               'payment_type':payment_type,
               'monthly_installment':monthly_installment,
               'monthly_rent':monthly_rent,
               '_token':token
                },
            dataType:'HTML',    
           success: function(data){
               $('#add_user').modal('hide');
               window.location.assign('<?php  redirect('money_recept');?>');
//             $('#view_user').html(data);
           }
       }); 
    }   
}

$(document).ready(function(){
     $('.mytable').delegate('button','click',function(event){
    var id=event.target.id;  
    $('#pre_id').val(id);
        });
    
     $('#delete').click(function(){
        var id=$('#pre_id').val();
       var token=$('input[name=_token]').val();
        $.ajax({
            url: 'delete_money_recept',
            method: 'post',
            data:{id:id,_token:token},
            success: function(){
              window.location.assign('<?php  redirect('money_recept');?>');
            }
            
        });
        
    });
    
    
    });
    function updateUserForm(ida){
         var token=$('input[name=_token]').val();
                
                $.ajax({
                url: 'money_recept_edit',
                method: 'post',
                data: {id:ida,_token:token},
                success: function (data) {
                    $('#up').html(data);
                }
        });
        
    }
    
    function viewDetails(idb){
         var token=$('input[name=_token]').val();
                
                $.ajax({
                url: 'money_recept_view_data',
                method: 'post',
                data: {id:idb,_token:token},
                success: function (data) {
                    $('#mr_view_data').html(data);
                }
        });
        
    }
    
    function updateData(){
        var client_name=$.trim($('input[name=edit_client_name]').val());
        var flat_type=$.trim($('input[name=edit_flat_type]').val());
          var payment_type=$.trim($('input[name=edit_payment_type]').val());
           var monthly_installment=$.trim($('input[name=edit_monthly_installment]').val());
    var monthly_rent=$.trim($('input[name=edit_monthly_rent]').val());
    var token=$('input[name=_token]').val();
    var id=$('input[name=id]').val();
//      alert(id);
            $.ajax({
                url: 'update_money_recept',
                method: 'post',
                  data: {
                      'client_name':client_name,
               'flat_type':flat_type,
               'payment_type':payment_type,
               'monthly_installment':monthly_installment,
               'monthly_rent':monthly_rent,
                      '_token':token,
                      'id':id
                      
                  },
                  dataType:'HTML',
                 
               success: function(data){                   
                    //$('#update').modal('hide');
                   window.location.assign('<?php redirect('money_recept');?>');
                  
                }
            });
    }
</script>

<script>
$(document).ready(function(){
    
 $('.example').dataTable();   
    
});

function formValidation(id){
    var val=$.trim($('#'+id).val());
    if(val===''){
        $('#'+id+'_error').html('');
        $('#'+id).css('border-color','red');
        
    }else{
        $('#'+id+'_error').html('');
        $('#'+id).css('border-color','green');
        
    }
    
    
}
</script>

<script>
$(document).ready(function(){
    
 $('.example').dataTable();   
    
});

</script>
