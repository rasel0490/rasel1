<?php echo Html::style('/css/bootstrap.min.css'); ?>

<?php echo Html::script('/js/jquery-1.11.3.min.js'); ?>

<?php echo Html::script('/js/bootstrap.min.js'); ?>


   
<table class="table table-hover example mytable" width="100%">
<?php echo e($i=1); ?>

<thead>
<tr>
<th>Sl</th>
<th>Client Name</th>
<th>Project Name</th>
<th>Project Category</th>
<th>Project Address</th>
<th>Flat Type</th>
<th>Monthly Installment</th>
<th>Monthly Rent</th>
<th>Payment Type</th>

</tr>
</thead>
<?php $__currentLoopData = $query; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
<tr>
<td><?php echo e($i++); ?></td>
<td><?php echo e($row->client_name); ?></td>
<td><?php echo e($row->P_Name); ?></td>
<td><?php echo e($row->P_Category); ?></td>
<td><?php echo e($row->P_Area); ?></td>
<td><?php echo e($row->flat_type); ?></td>
<td><?php echo e($row->monthly_installment); ?></td>
<td><?php echo e($row->monthly_rent); ?></td>
<td><?php echo e($row->payment_type); ?></td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
</table>