<?php echo Html::style('/css/bootstrap.min.css'); ?>

<?php echo Html::style('/css/datatables.css'); ?>

<?php echo Html::script('/js/bootstrap.min.js'); ?>


<?php echo Html::script('/js/jquery-1.11.3.min.js'); ?>

<?php echo Html::script('/js/datatables.js'); ?>

<?php echo Form::open(['route'=>'mrcont.store']); ?>

<table class="table table-hover">
    
    <tr>
        <th>Client Name</th>
        <td><?php echo Form::text('client_name','',['class'=>'form-control']); ?></td>
        
        
    </tr>
   
    <tr>
    <th>Flat Type</th>
        <td><?php echo Form::text('flat_type','',['class'=>'form-control']); ?></td>
    </tr>
    
    <tr>
    <th>Payment Type</th>
        <td><?php echo Form::text('payment_type','',['class'=>'form-control']); ?></td>
    </tr>
    
    <tr>
    <th>Monthly Installment</th>
        <td><?php echo Form::text('monthly_installment','',['class'=>'form-control']); ?></td>
    </tr>
    
     <tr>
    <th>Monthly Rent</th>
        <td><?php echo Form::text('monthly_rent','',['class'=>'form-control']); ?></td>
    </tr>
    
    <tr>
        <td></td>
        <td><?php echo Form::submit('save',['class'=>'btn btn-info']); ?></td>
    </tr>
    
</table>
<?php echo Form::close(); ?>