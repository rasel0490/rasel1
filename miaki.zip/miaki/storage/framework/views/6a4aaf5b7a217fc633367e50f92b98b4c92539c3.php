<?php echo Html::style('/css/bootstrap.min.css'); ?>

<script>
function hide(){
    document.getElementById('pr').style.display="none";
    
}
</script>

<div id="pr">    
    <a style="float:left; margin:20px 10px 30px 10px;" href="allotment_price_installment" class="" ><img class="img-responsive" src="images/back-icon.png" alt="back"></a>
<a  style="float:left; margin:20px 10px 30px 10px;" href="Javascript:void(0)" onclick="hide();window.print"><img class="img-responsive"  src="images/icon_print_preview.png"></a>
<a  style="float:left; margin:20px 10px 30px 10px;" href="user_word"><img src="images/word.png"></a>
<a  style="float:left; margin:20px 10px 30px 10px;" href="user_excel"><img src="images/excel.png"></a>
<a  style="float:left; margin:20px 10px 30px 10px;" href="user_pdf"><img src="images/pdf.png"></a>
</div>

<table class="table table-bordered example mytable" width="100%">
<thead>
<tr>
<th>Sl</th>
<th>Client Name</th>
<th>Flat Type</th>
<th>Total Amount</th>
</tr>
</thead>

<?php echo e($i=1); ?>

<?php $__currentLoopData = $query; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
<tr>
<td><?php echo e($i++); ?></td>
<td><?php echo e($row->Client_Name); ?></td>
<td><?php echo e($row->Flat_Type); ?></td>
<td><?php echo e($row->Total_Amount); ?></td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
</table>


