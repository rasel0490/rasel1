<?php echo Html::style('/css/bootstrap.min.css'); ?>


<?php echo Html::script('/js/jquery-1.12.3.min.js'); ?>

<?php echo Html::script('/js/bootstrap.min.js'); ?>

<style>
    img{
        height: 70px;
        width:70px;
    }
</style>
<h1 align="center">East West Property Development (Pvt.) Ltd.</h1>
<h2 align="center"> Dhanmondi,Dhaka</h2>
<table class="table table-hover">
    <tr>
    <th>Picture</th>
        <td><?php echo e(HTML::image('uploads/'.$query->Client_Picture)); ?></td>
    </tr>
    <tr>
        <th>Client Name</th>
        <td><?php echo $query->Client_Name; ?></td>
    </tr>
    <tr>
        <th>Client Address</th>
        <td><?php echo $query->Client_Address; ?></td>
    </tr>
     <tr>
        <th>Client Phone</th>
        <td><?php echo $query->Client_Phone; ?></td> 
    </tr>
     <tr>
        <th>Client Email</th>
        <td><?php echo $query->Client_Email; ?></td>
    </tr>
    </table>