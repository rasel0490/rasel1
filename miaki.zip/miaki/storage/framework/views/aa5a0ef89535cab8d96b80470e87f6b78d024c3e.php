<?php echo Html::style('/css/bootstrap.min.css'); ?>

<?php echo Html::script('/js/jquery-1.12.3.min.js'); ?>

<?php echo Html::script('/js/bootstrap.min.js'); ?>

<!--<?php echo Form::model($query, [
    'method' => 'PATCH',
    'route' => ['mycount1.update', $query->Allotment_Status_ID]
]); ?>-->
<table class="table table-hover">
<?php echo Form::hidden('id',$query->Allotment_Status_ID,array('class'=>'form-control','id'=>'id')); ?>

    <tr>
        <th>Sale</th>
        <td><?php echo Form::text('edit_sale',$query->Sale,array('class'=>'form-control','id'=>'edit_sale')); ?></td>
        
        
    </tr>
    <tr>
        <th>Not Sale</th>
        <td><?php echo Form::text('edit_not_sale',$query->Not_Sale,array('class'=>'form-control','id'=>'edit_not_sale')); ?></td>
        
    </tr>
    <tr>
        <th>Flat Type</th>
        <td><?php echo Form::text('edit_flat_type',$query->Flat_Type,array('class'=>'form-control','id'=>'edit_flat_type')); ?></td>        
    </tr>  
</table>
<!--<?php echo Form::close(); ?>-->




