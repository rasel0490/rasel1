<?php echo Html::style('/css/bootstrap.min.css'); ?>

<?php echo Html::style('/css/datatables.css'); ?>

<?php echo Html::script('/js/bootstrap.min.js'); ?>


<?php echo Html::script('/js/jquery-1.11.3.min.js'); ?>

<?php echo Html::script('/js/datatables.js'); ?>

<style>
    img{
        height: 120px;
        width:100px;
    }
</style>
<!--<?php echo Form::model($query, [
    'method' => 'PATCH',
    'route' => ['mycont.update', $query->id]
]); ?>-->
<table class="table table-hover">
    <?php echo Form::hidden('id',$query->id,array('class'=>'form-control','id'=>'id')); ?>

    
    <tr>
        <th>Title </th>
        <td><?php echo Form::text('edit_title',$query->title,array('class'=>'form-control','id'=>'edit_title')); ?></td>
        
        <th>Published</th>
         <td><?php echo Form::radio('edit_published',$query->published,array('class'=>'','id'=>'yes')); ?>YES
         
             <?php echo Form::radio('edit_published','$query->published',array('id'=>'no')); ?>NO
         </td>
         
         <th>Featured</th>
         <td style="margin-left: -40px"><?php echo Form::radio('edit_featured',$query->featured,array('class'=>'','id'=>'yes')); ?>YES
         
           <?php echo Form::radio('edit_featured',$query->featured,array('class'=>'','id'=>'no')); ?>NO
         </td>
    </tr>
    
    
    <tr>
        <th>Category</th>
        <td>
            <?php echo Form::text('edit_category',$query->category,array('class'=>'form-control','id'=>'edit_category')); ?>

        </td>
        
        <th>Price</th>
        <td><?php echo Form::text('edit_price',$query->price,array('class'=>'form-control','id'=>'edit_price')); ?></td>
        
        <th>Discount(%)</th>
        <td><?php echo Form::text('edit_discount',$query->discount,array('class'=>'form-control','id'=>'Edit_discount')); ?></td>
    </tr> 
    
    <tr>
    <th>Partner</th>
        <td>
            <?php echo Form::text('edit_partner',$query->partner,array('class'=>'form-control','id'=>'edit_partner')); ?>

        </td>
        
        <th>File</th>
          <td><?php echo Form::file('edit_image'); ?></td>
        </tr>
    
 <tr>
     <th>Description</th>
        <td><?php echo Form::textarea('edit_description',$query->description,array('class'=>'form-control ','id'=>'edit_description','style'=>'height:160px; width:200px')); ?></td>
        
        <th>Thambnall</th>
    
        <td><?php echo Form::file('edit_image2'); ?></td> 
        <td><?php echo e(Html::image('uploads/'.$query->file)); ?></td>
    </tr>
    
</table>
<!--<?php echo Form::close(); ?>-->