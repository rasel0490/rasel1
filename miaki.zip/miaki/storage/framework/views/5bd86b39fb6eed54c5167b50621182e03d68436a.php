<?php echo Html::style('/css/bootstrap.min.css'); ?>

<?php echo Html::style('/css/datatables.css'); ?>

<?php echo Html::script('/js/jquery-1.11.3.min.js'); ?>

<?php echo Html::script('/js/bootstrap.min.js'); ?>

<?php echo Html::script('/js/datatables.js'); ?>

    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <body style="background-color:#076F91">
        
    <p><h1 style="font-weight: bold; color: white" align="center">Bangla Track MIAKI</h1>
    <h3 style="font-weight: bold; color: white" align="center">Banani Dhaka 1219</h3>
    <h3 style="font-weight: bold; color: white" align="center">Cell: 01916580472</h3>
</p>
<!--    //<a href="Rent_Info.index" class="btn btn-default">Home</a>-->
<a style="margin: 10px 0px 10px 0px; " href="#" class="btn btn-md btn-default" >Home</a>
   <button style="margin: 10px 0px 10px 0px" data-toggle="modal" data-target="#add_user" class="btn btn-md btn-primary">Add+</button>
<div id="add_user" class="modal fade" role="dialog">
    <div class="modal-dialog modal-lg">
       <?php echo Form::open(array('method'=>'post','id'=>'save','files'=>'true')); ?>

        <div class="modal-content">
            <div class="modal-header">
                <div class="col-sm-6"><h3>New Entry</h3></div>
               <div class="col-sm-6"> <button type="button" class="close" data-dismiss="modal">&times;</button> </div>   
            </div>
            
            <div class="modal-body">
                <table class="table table-hover" id="view_user">
    
    <tr>
        <th>Title</th>
        <td><?php echo Form::text('title','',array(
    'class'=>'form-control',
    'id'=>'title',
    'placeholder'=>'Product Title',
    'onkeyup'=>'formValidation(id)',
    'onchange'=>'formValidation(id)'
            
            )); ?></td>
        
        <th>Published</th>
         <td><?php echo Form::radio('published','yes',array(
    'class'=>'',
    'id'=>'yes',
    'onkeyup'=>'formValidation(id)',
    'onchange'=>'formValidation(id)'
            
            )); ?>YES
         
            
        <?php echo Form::radio('published','no',array(
    'class'=>'form-control',
    'id'=>'no',
    'onkeyup'=>'formValidation(id)',
    'onchange'=>'formValidation(id)'
            
            )); ?>NO
         </td>
        
        <th>Featured</th>
         <td><?php echo Form::radio('featured','yes',array(
    'class'=>'',
    'id'=>'yes',
    'onkeyup'=>'formValidation(id)',
    'onchange'=>'formValidation(id)'
            
            )); ?>YES
         
            
        <?php echo Form::radio('featured','no',array(
    'class'=>'',
    'id'=>'no',
    'onkeyup'=>'formValidation(id)',
    'onchange'=>'formValidation(id)'
            
            )); ?>NO
         </td>
    </tr>
     <td></td><td id="title_error" style="color:red"></td>
    <tr>
        <th>Category</th>
        <td>
            <?php echo Form::select('category',array('placeholder'=>'Select category','Picture'=>'Picture','Video'=>'Video'),null,['class'=>'form-control','id'=>'category','onkeyup'=>'formValidation(id)','onchange'=>'formValidation(id)']); ?>

        </td>
        
        <th>Price</th>
        <td><?php echo Form::text('price','',array(
    'class'=>'form-control',
    'id'=>'price',
    'placeholder'=>'Product Price',
    'onkeyup'=>'formValidation(id)',
    'onchange'=>'formValidation(id)'
            
            )); ?></td>
        
         <th>Discount(%)</th>
        <td><?php echo Form::text('discount','',array(
    'class'=>'form-control',
    'id'=>'discount',
    'placeholder'=>'Discount Rate',
    'onkeyup'=>'formValidation(id)',
    'onchange'=>'formValidation(id)'
            
            )); ?></td>
    </tr>
    <td></td> <td></td><td></td><td id="price_error" style="color:red"></td><td></td>
    
    <tr>
        <th>Partner</th>
        <td>
            <?php echo Form::select('partner',array('placeholder'=>'Select partner','Spondon'=>'Spondon','Infinity'=>'Infinity','Bangla Track'=>'Bangla Track'),null,['class'=>'form-control','id'=>'partner','onkeyup'=>'formValidation(id)','onchange'=>'formValidation(id)']); ?>

        </td>
        
        <th>File</th>
    
        <td><?php echo Form::file('image'); ?></td>
        
        
    </tr>
    
    
    
    <tr> <th>Description</th>
        <td><?php echo Form::textarea('description','',array(
    'class'=>'form-control ',
    'id'=>'description',
    'placeholder'=>'Product Description',
    'onkeyup'=>'formValidation(id)',
    'style'=>'height:160px; width:200px',
    'onchange'=>'formValidation(id)'
            
            )); ?></td>
        
        <th>Thambnall</th>
    
        <td><?php echo Form::file('image2'); ?></td>
    </tr>
    <td></td>  <td id="description_error" style="color:red"></td>
                </table>
    
            </div>
            
             <div class="modal-footer">
               <?php echo Form::button('submit',array('class'=>'btn btn-success btn-sm','onclick'=>'save_data()')); ?>

                
               <?php echo Form::button('Cancel',array('class'=>'btn btn-danger btn-sm','data-dismiss'=>'modal')); ?>

               
           </div>
            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
        <?php echo Form::close(); ?>

        </div>
    </div>
</div>




<table class="table table-hover example mytable" width="100%">
<?php echo e($i=1); ?>

<thead>
<tr>
<th>#</th>
<th>Title</th>
<th>Category</th>
<th>Partner</th>
<th>Price</th>
<th>Discount</th>
<th>Status</th>
<th>Featured</th>
<th>Edit</th>
<th>Delete</th>
<!--<th>View</th>-->
</tr>
</thead>
<?php $__currentLoopData = $query; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
<tr>
<td><?php echo e($i++); ?></td>
<td><?php echo e($row->title); ?></td>
<td><?php echo e($row->category); ?></td>
<td><?php echo e($row->partner); ?></td>
<td><?php echo e($row->price); ?></td>
<td><?php echo e($row->discount); ?></td>
<td><?php echo e($row->published); ?></td>
<td><?php echo e($row->featured); ?></td>

<td>

<?php echo Form::button('<img src="images/edit_icon.png">',array('class'=>'btn btn-info','data-toggle'=>'modal','data-target'=>'#update','id'=>$row->id,'onclick'=>"updateUserForm(id)")); ?>

</td>
<td><?php echo Form::button('<img src="images/delete_icon.png">',array('class'=>'btn btn-danger','data-toggle'=>'modal','data-target'=>'#delete_nc','id'=>$row->id)); ?></td>

</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>


</table>

<!--<?php echo Form::close(); ?>-->

<!-- Delete Modal Start -->
<div id="delete_nc" class="modal fade" role="dialog">
    <div class="modal-dialog modal-md">

         Modal content
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <img src="images/warning.png"> <strong style="color: red">WARNING !</strong>
            </div>
            <div class="modal-body">
                <input type="hidden" id="pre_id" value="">
                Are you sure you want to delete this record ?<br>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-sm btn-danger" id="delete">Yes</button>
                <button type="button" class="btn btn-sm btn-success" data-dismiss="modal">No</button>
            </div>
        </div>
    </div>
</div>
<!-- Delete Modal End-->
<!-- Modal for update Starts Here -->
<div id="update" class="modal fade" role="dialog">
    <div class="modal-dialog modal-lg">

        <!-- Modal content-->
<!--        <?php echo Form::open(array('method'=>'post','id'=>'update_c')); ?>-->
<!--        <form id="update_c"  method="post" enctype="multipart/form-data">-->
 <?php //echo form_open_multipart('home/updateleftmenuse');?>
        <div class="modal-content" style="">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <strong>Edit Entry</strong>
            </div>
            <div class="modal-body">
                
                <div id="up"></div>
            </div>
            <div class="modal-footer">
                <input type="button" class="btn btn-sm btn-success" onclick="updateData()" value="Update">
        <button type="button" class="btn btn-sm btn-danger" data-dismiss="modal">Cancel</button>
    </div>
        </div>
     
        <?php echo Form::close(); ?>

    </div>
</div>
<!-- Modal for update Ends Here -->


</body>
<script>
    window.Laravel = <?php echo json_encode([
        'csrfToken' => csrf_token(),
    ]); ?>
</script>

<script>
function save_data(){
    var form=$('#save').get(0);
  var title=$('input[name=title]').val();
   var published=$('radio[name=published]').val();
   var featured=$('radio[name=featured]').val();
    var category=$('select[name=category]').val();
    var price=$('input[name=price]').val();
    var discount=$('input[name=discount]').val();
    var partner=$('select[name=partner]').val();
    var description=$('input[name=description]').val();
    var file=$('input[name=image]').val();
     var thambnall=$('input[name=image2]').val();
    var token=$('input[name=_token]').val();
    
    if(title===""|| price===""|| description===""){
        
        if(title===""){
        $('#title_error').html("Please Enter product title");
        $('#title').css('border-color','red');
    }
    if(price===""){
        $('#price_error').html("Please Enter price");
        $('#price').css('border-color','red');
    }
    if(description===""){
        $('#description_error').html("Please Enter product description");
        $('#description').css('border-color','red');
    }
    }else{
       $.ajax({
          
           url:'miaki_save_data',
           method:'post',

               data: new FormData(form),
            processData:false,
            contentType:false,
           success: function(){
                $('#add_user').modal('hide');
               window.location.assign('<?php  redirect('BT');?>');

           }
       }); 
    }
}

$(document).ready(function(){
     $('.mytable').delegate('button','click',function(event){
    var id=event.target.id;  
    $('#pre_id').val(id);
        });
    
     $('#delete').click(function(){
        var id=$('#pre_id').val();
       var token=$('input[name=_token]').val();
        $.ajax({
            url: 'delete_miaki',
            method: 'post',
            data:{id:id,_token:token},
            success: function(){
              window.location.assign('<?php  redirect('BT');?>');
            }
            
        });
        
    });
    
    
    });
    function updateUserForm(ida){
         var token=$('input[name=_token]').val();
                
                $.ajax({
                url: 'miaki_edit',
                method: 'post',
                data: {id:ida,_token:token},
                success: function (data) {
                    $('#up').html(data);
                }
        });
        
    }
    
    function updateData(){
          var form=$('#update_c').get(0);
        var title=$.trim($('input[name=edit_title]').val());
   var published=$.trim($('radio[name=edit_published]').val());
   var featured=$.trim($('radio[name=edit_featured]').val());
    var category=$.trim($('select[name=edit_category]').val());
    var price=$.trim($('input[name=edit_price]').val());
    var discount=$.trim($('input[name=edit_discount]').val());
    var partner=$.trim($('select[name=edit_partner]').val());
    var description=$.trim($('input[name=edit_description]').val());
    var file=$.trim($('input[name=edit_image]').val());
     var thambnall=$.trim($('input[name=edit_image2]').val());
          
    
    var token=$('input[name=_token]').val();
    var id=$('input[name=id]').val();
//      alert(id);
            $.ajax({
                url: 'update_miaki',
                method: 'post',
//                  data: {
//                      'flat_type':flat_type,
//                      'monthly_rent':monthly_rent,
//                      '_token':token,
//                      'id':id
//                      
//                  },
//                  dataType:'HTML',
                 
              data: new FormData(form),
            processData:false,
            contentType:false,
           success:function(data){          

        window.location.assign('<?php redirect('BT');?>');
       
                }
            });
    }
</script>

<script>
$(document).ready(function(){
    
 $('.example').dataTable();   
    
});

function formValidation(id){
    var val=$.trim($('#'+id).val());
    if(val===''){
        $('#'+id+'_error').html('');
        $('#'+id).css('border-color','red');
        
    }else{
        $('#'+id+'_error').html('');
        $('#'+id).css('border-color','green');
        
    }
    
    
}
</script>
