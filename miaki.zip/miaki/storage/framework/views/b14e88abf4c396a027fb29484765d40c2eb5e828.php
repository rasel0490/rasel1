<!--<?php if(!$abc=Session::get('sess_user_name')): ?>
<script type="text/javascript">
    window.location = "<?php echo e(url('login')); ?>";
</script>
<?php echo e($abc); ?>

<?php endif; ?>-->

<?php echo Html::style('/css/bootstrap.min.css'); ?>

<?php echo Html::style('/css/datatables.css'); ?>

<?php echo Html::script('/js/jquery-1.12.3.min.js'); ?>

<?php echo Html::script('/js/datatables.js'); ?>

<?php echo Html::script('/js/bootstrap.js'); ?>

<?php echo Html::script('/js/bootstrap.min.js'); ?>

<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

<body>
    <a style="margin: 40px 0px 10px 0px; " href="template" class="btn btn-md btn-default" >Home</a>
    <a href="user_print" class="btn btn-success" style="margin-top:40px">Print</a>
<a href="<?php echo e(URL::to('user_report')); ?>" class="btn btn-info" style="margin-top:40px">Report</a>
<a href="<?php echo e(URL::to('logout')); ?>" class="btn btn-danger" style="margin-top:40px">Logout</a>
<button data-toggle="modal" data-target="#add" class="btn btn-primary" style="margin-top:40px">Add User</button>
<div id="add" class="modal fade" role="dialog">
    <div class="modal-dialog modal-lg">
<!--        <form id="save" method="post" enctype="">-->
<!--            <?php echo Form::open(['route'=>'mycount1.store','method'=>'post','id'=>'save']); ?>-->
<?php echo Form::open(array('method'=>'post','id'=>'save')); ?>

            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>                    
                </div>
                <div class="modal-body">
                    <table class="table table-hover" id='view_tbl'>
    
    <tr>
        <th>Client Name</th>
        <td>
            <?php echo Form::text('client_name','',array(
            'class'=>'form-control',
            'id'=>'client_name',
            'onchange'=>'names(id)',
            'onkeyup'=>'names(id)'
            )); ?>

        </td>
    </tr>
    <tr>
        <td></td> 
        <td id="client_name_error" style="color:red"></td>
    </tr>
    <tr>
        <th>Flat Type</th>
        <td>
            <?php echo Form::text('flat_type','',array(
            'class'=>'form-control',
            'id'=>'flat_type',
            'onchange'=>'names(id)',
            'onkeyup'=>'names(id)'
            )); ?>

        </td>        
    </tr>
    <tr>
        <td></td> 
        <td id="flat_type_error" style="color:red"></td>
    </tr>
    <tr>
        <th>Total Amount</th>
        <td>
            <?php echo Form::text('total_amount','',array(
            'class'=>'form-control',
            'id'=>'total_amount',
            'onchange'=>'names(id)',
            'onkeyup'=>'names(id)'
            )); ?>

        </td>        
    </tr>
    <tr>
        <td></td> 
        <td id="total_amount_error" style="color:red"></td>
    </tr>
    <tr>
        <th>Monthly Amount</th>
        <td>
            <?php echo Form::text('monthly_amount','',array(
            'class'=>'form-control',
            'id'=>'monthly_amount',
            'onchange'=>'names(id)',
            'onkeyup'=>'names(id)'
            )); ?>

        </td>        
    </tr>
    <tr>
        <td></td> 
        <td id="monthly_amount_error" style="color:red"></td>
    </tr>
    <tr>
        <th>Duration</th>
        <td>
            <?php echo Form::text('duration','',array(
            'class'=>'form-control',
            'id'=>'duration',
            'onchange'=>'names(id)',
            'onkeyup'=>'names(id)'
            )); ?>

        </td>        
    </tr>
    <tr>
        <td></td> 
        <td id="duration_error" style="color:red"></td>
    </tr>
    <tr>
        <th>Balance</th>
        <td>
            <?php echo Form::text('balance','',array(
            'class'=>'form-control',
            'id'=>'balance',
            'onchange'=>'names(id)',
            'onkeyup'=>'names(id)'
            )); ?>

        </td>        
    </tr>
    <tr>
        <td></td> 
        <td id="balance_error" style="color:red"></td>
    </tr>
    <tr>
        <th>Late Interest</th>
        <td>
            <?php echo Form::text('with_late_interest','',array(
            'class'=>'form-control',
            'id'=>'with_late_interest',
            'onchange'=>'names(id)',
            'onkeyup'=>'names(id)'
            )); ?>

        </td>        
    </tr>
    <tr>
        <td></td> 
        <td id="with_late_interest_error" style="color:red"></td>
    </tr>
    </table>
                </div>
                <div class="modal-footer">
                <?php echo Form::button('save',array('class'=>'btn btn-success btn-sm','onclick'=>'save_data()')); ?>                
               <?php echo Form::button('Cancel',array('class'=>'btn btn-danger btn-sm','data-dismiss'=>'modal')); ?>

                </div>
                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                <?php echo Form::close(); ?>

            </div>        
    </div>
</div>
<table class="table table-bordered example mytable" width="100%">
   
<thead>
<tr>
<th>Sl</th>
<th>Client Name</th>
<th>Flat Type</th>
<th>Total Amount</th>
<th>Delete</th>
<th>Update</th>
<th>View</th>

</tr>
</thead>

<?php echo e($i=1); ?>

<?php $__currentLoopData = $query; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
<tr>
<td><?php echo e($i++); ?></td>
<td><?php echo e($row->Client_Name); ?></td>
<td><?php echo e($row->Flat_Type); ?></td>
<td><?php echo e($row->Total_Amount); ?></td>
<td><?php echo Form::button('Delete',array('class'=>'btn btn-danger','data-toggle'=>'modal','data-target'=>'#delete_nc','id'=>$row->Allotment_ID)); ?></td>
<td><?php echo Form::button('Edit',array('class'=>'btn btn-info','data-toggle'=>'modal','data-target'=>'#update_nc','id'=>$row->Allotment_ID,'onclick'=>"updateUserForm(id)")); ?></td>
<td><?php echo Form::button('View',array('class'=>'btn btn-success','data-toggle'=>'modal','data-target'=>'#viewD','id'=>$row->Allotment_ID,'onclick'=>"viewDetails(id)")); ?></td>
<!--<td>
<?php echo Form::open([
'method' => 'DELETE',
'route' => ['mycount.destroy', $row->Allotment_ID]
]); ?>

<?php echo Form::submit('Delete', ['class' => 'btn btn-danger']); ?>

<?php echo Form::close(); ?>

</td>
<td><a href="<?php echo e(route('mycount.edit',$row->Allotment_ID)); ?>" class="btn btn-primary">Update</a></td>-->
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
</table>


<div id="delete_nc" class="modal fade" role="dialog">
<div class="modal-dialog modal-md">
<div class="modal-content">
<div class="modal-header">
<button type="button" class="close" data-dismiss="modal">&times;</button>
<img src="images/warning.jpg" height="50px" width="50px"/><strong style="color:red">Warning!</strong>
</div>
<div class="modal-body">
    <input type="hidden" id="pre_id" value=""/>
Do you want to delete data?
</div>
<div class="modal-footer">
<button class="btn btn-sm btn-danger" id="delete">Yes</button>
<button type="button" class="btn btn-sm btn-success" data-dismiss="modal">No</button>
</div>
</div>
</div>
</div>
    
<div id="update_nc" class="modal fade" role="dialog">
<div class="modal-dialog modal-md">
    <?php echo Form::open(array('method'=>'post','id'=>'update_c')); ?>

<div class="modal-content">
<div class="modal-header">
<button type="button" class="close" data-dismiss="modal">&times;</button>
</div>
<div class="modal-body" id="table_body">    
    <div id="up"></div>
</div>
<div class="modal-footer">
<input type="button" class="btn btn-sm btn-danger" onclick="updateData()" value="Update">
<button type="button" class="btn btn-sm btn-success" data-dismiss="modal">No</button>
</div>
</div>
<?php echo Form::close(); ?>

</div>
</div>
    
<div id="viewD" class="modal fade" role="dialog">
<div class="modal-dialog modal-md">
<div class="modal-content">
<div class="modal-header">
<button type="button" class="close" data-dismiss="modal">&times;</button>
<strong>View Allotment Installment</strong>
</div>
<div class="modal-body" id="table_body">    
    <div id="view_data"></div>
</div>
<div class="modal-footer">
    <button type="button" class="btn btn-sm btn-success" data-dismiss="modal">No</button>
</div>
</div>
</div>
</div>    
    
</body>
<script>
    window.Laravel = <?php echo json_encode([
        'csrfToken' => csrf_token(),
    ]); ?>
</script>

<script>
    function names(id) {
var val = $.trim($('#' + id).val());
if (val === '') {
$('#' + id + '_error').html('');
$('#' + id).css('border-color', 'red');
} else {
$('#' + id + '_error').html('');
$('#' + id).css('border-color', 'green');
}
}

$(document).ready(function(){
    
	$('.example').dataTable();
        
});

</script>
<script>
function save_data(){    
    var form=$('#save').get(0);
    //var base_url="<?php echo e(URL::to('/')); ?>";       

            var client_name=$('input[name=client_name]').val();
            var flat_type=$('input[name=flat_type]').val();
            var total_amount=$('input[name=total_amount]').val();
            var monthly_amount=$('input[name=monthly_amount]').val();
            var duration=$('input[name=duration]').val();
            var balance=$('input[name=total_amount]').val();
            var with_late_interest=$('input[name=with_late_interest]').val();
            var token=$('input[name=_token]').val();

            if(client_name===''||flat_type===''||total_amount===''||monthly_amount===''||duration===''||balance===''||with_late_interest===''){
                if(client_name==''){
                    $('#client_name_error').html('Please Enter Sale Status');
                    $('#client_name').css("border-color","red");
                }
                if(flat_type==''){
                    $('#flat_type_error').html('Please Enter Sale Status');
                    $('#flat_type').css("border-color","red");
                }
                if(total_amount==''){
                    $('#total_amount_error').html('Please Enter Flat Type');
                    $('#total_amount').css("border-color","red");
                }
                if(monthly_amount==''){
                    $('#monthly_amount_error').html('Please Enter Flat Type');
                    $('#monthly_amount').css("border-color","red");
                }
                if(duration==''){
                    $('#duration_error').html('Please Enter Flat Type');
                    $('#duration').css("border-color","red");
                }
                if(balance==''){
                    $('#balance_error').html('Please Enter Flat Type');
                    $('#balance').css("border-color","red");
                }
                if(with_late_interest==''){
                    $('#with_late_interest_error').html('Please Enter Flat Type');
                    $('#with_late_interest').css("border-color","red");
                }
            }else{              
                $.ajax({
                    url:'save_data1',
                    method:'post',
                    data:{
                        'client_name':client_name,
                        'flat_type':flat_type,
                        'total_amount':total_amount,
                        'monthly_amount':monthly_amount,
                        'duration':duration,
                        'balance':balance,
                        'with_late_interest':with_late_interest,
                        '_token':token
                    },
                    dataType:'HTML',                    
                    success:function(data){
                        $('#add').modal('hide');
                        window.location.assign('<?php  redirect('allotment_price_installment');?>');
                    }
                });
            }    
}

$(document).ready(function(){
        
     $('.mytable').delegate('button','click',function(event){
    var id=event.target.id;  
    $('#pre_id').val(id);    
    });
    
     $('#delete').click(function(){
        var id=$('#pre_id').val();
       var token=$('input[name=_token]').val();
        $.ajax({
            url:'delete_data1',
            method:'post',
            data:{id:id,_token:token},
            success: function(){
              window.location.assign('<?php  redirect('allotment_price_installment');?>');
            }
            
        });
        
    });

        
    });
    
    function updateUserForm(ida){
         var token=$('input[name=_token]').val();
                
                $.ajax({
                url: 'edit_form1',
                method: 'post',
                data: {id:ida,_token:token},
                success: function (data) {
                    $('#up').html(data);
                }
        });
        
    }
    
    function viewDetails(idb){
         var token=$('input[name=_token]').val();
                
                $.ajax({
                url: 'view_details1', 
                method: 'post',
                data: {id:idb,_token:token},
                success: function (data) {
                    $('#view_data').html(data);
                }
        });
        
    }
    
    function updateData(){
        
        var client_name=$.trim($('input[name=edit_client_name]').val());
        var flat_type=$.trim($('input[name=edit_flat_type]').val());
        var total_amount=$.trim($('input[name=edit_total_amount]').val());
        var monthly_amount=$.trim($('input[name=edit_monthly_amount]').val());
        var duration=$.trim($('input[name=edit_duration]').val());
        var balance=$.trim($('input[name=edit_balance]').val());
        var with_late_interest=$.trim($('input[name=edit_with_late_interest]').val());
        var token=$('input[name=_token]').val();
    var id=$('input[name=id]').val();
//      alert(id);
            $.ajax({
                url: 'update_data1',
                method: 'post',
                  data: {
                      'client_name':client_name,
                      'flat_type':flat_type,
                      'total_amount':total_amount,
                      'monthly_amount':monthly_amount,
                      'duration':duration,
                      'balance':balance,
                      'with_late_interest':with_late_interest,
                      '_token':token,
                      'id':id                      
                  },
                  dataType:'HTML',                 
               success: function (data) {                   
                    $('#update_nc').modal('hide');
                    window.location.assign('<?php  redirect('allotment_price_installment');?>');
                  
                }
            });
    }
</script>