<?php echo Html::style('/css/bootstrap.min.css'); ?>

<script>
function hide(){
    document.getElementById('pr').style.display="none";
    
}
</script>

 <p><h1 style="font-weight: bold" align="center">Real Estate Management System</h1>
    <h3 style="font-weight: bold" align="center">Rampura Dhaka 1219</h3>
    <h3 style="font-weight: bold" align="center">Cell: 01916580472</h3>
</p>
<div id="pr" style="margin:20px 10px 30px 10px">
  
<a style="float:left; margin:20px 10px 30px 10px;" href="rent_info" class="" ><img class="img-responsive" src="images/back-icon.png" alt="back"></a>
 <a style="float:left; margin:20px 10px 30px 10px;" href="Javascript:void(0)" class="" onclick="hide();window.print"><img class="img-responsive" src="images/icon_print_preview.png" alt="print_preview"></a>
<a style="float:left; margin:20px 10px 30px 10px;" href="rent_info_word" class="" ><img class="img-responsive" src="images/icon-word.png" alt="word"></a>
<a style="float:left; margin:20px 10px 30px 10px;" href="rent_info_excel" class="" ><img class="img-responsive" src="images/icon-excel.png" alt="excel"></a>
<a style="float:left; margin:20px 10px 30px 10px;" href="rent_info_pdf" class="" ><img class="img-responsive" src="images/icon-pdf.png" alt="pdf"></a>
</div>

<table class="table table-hover example mytable" width="100%">
<?php echo e($i=1); ?>


<tr>
<th>Sl</th>
<th>Flat Type</th>
<th>Monthly Rent</th>

</tr>

<?php $__currentLoopData = $query; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
<tr>
<td><?php echo e($i++); ?></td>
<td><?php echo e($row->flat_type); ?></td>
<td><?php echo e($row->monthly_rent); ?></td>


</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>


</table>