<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Miaki extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('bangla_track',function(Blueprint $table){
          $table->increments('id');
          $table->string('title');
          $table->string('category'); 
          $table->string('partner');
          $table->string('description'); 
          $table->string('price');
          $table->string('discount'); 
          $table->string('published');
          $table->string('featured'); 
          $table->string('file');
          $table->string('thumbnall'); 
          $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
    }
}
