<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
   // return view('');
});
Route:: get('template','Miaki_Controller@temp');
Route::resource('BT','Miaki_Controller@index');
Route:: resource('add_user','Miaki_Controller@create_user');
Route:: resource('mycont','Miaki_Controller');
Route:: post('miaki_save_data','Miaki_Controller@store');
Route:: post('delete_miaki','Miaki_Controller@destroy');
Route:: post('miaki_edit','Miaki_Controller@edit');
Route:: post('update_miaki','Miaki_Controller@update');




Route::get('login','loginController@showLogin');
Route::get('logout','loginController@logOut');
Route::post('check_login','loginController@checkLogin');
