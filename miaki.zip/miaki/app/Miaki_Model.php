<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Miaki_Model extends Model
{
    protected $primaryKey='id';
    public $table="rent_info";
    public $filltable=['title','category','partner','description','price','discount','published','featured','file','thumbnall'];
}
