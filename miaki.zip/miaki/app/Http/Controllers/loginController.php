<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\loginModel;

use Session;
use DB;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Redirect;
use Auth;

class loginController extends Controller
{
    public function showLogin(Request $request) {

        return view('login.index');
    }
    
    public function checkLogin(Request $request) {
        $email = $request->email;
        $user_name = $request->username;
        $user_pass = $request->password;
        $user_token = $request->_token;
        
        // dd($request->all());
        $rules = array(
            'email'=>'required',
            'username' => 'required|max:10|min:5',
            'password' => 'required|alphaNum|min:4'
        );
        $validator = Validator::make(Input::all(), $rules);
        if ($validator->fails()) {
            return Redirect::to('login')
                            ->withErrors($validator)
                            ->withInput(Input::except('password'));
        }else {
                        $auth = 
                    loginModel::where('email', '=', $email)->where('uname', '=', $user_name)->where('pass', '=', $user_pass)->orwhere('remember_token',$user_token)->first();
       if ($auth) {
           $auth_email=$auth->email;
           $auth_user_name=$auth->uname;
               $auth_user_pass=$auth->pass;
               $auth_token=$auth->remember_token;
               $s_email=$request->session()->put('sess_email',$auth_email);
               $s_user_name=$request->session()->put('sess_user_name',$auth_user_name);
               $s_user_pass=$request->session()->put('sess_user_pass',$auth_user_pass);
                return Redirect::to('infinity');
            
       }else {
           return Redirect::to('login');
       }
                        }
        
    }
  public function logOut(Request $request) {
      $request->session()->forget('sess_email');
        $request->session()->forget('sess_user_name');
        $request->session()->forget('sess_user_pass');
        $request->session()->flush();
        return Redirect::to('template');
    }  
}
