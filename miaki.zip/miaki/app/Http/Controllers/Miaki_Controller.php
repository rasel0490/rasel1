<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Miaki_Model;
use DB;
class Miaki_Controller extends Controller
{
    public function index(Request $request){
        $data = DB::table('rent_info')->get();
        return view('Rent_Info.rent_info_user_view',['query'=>$data]);
 }
 public function temp(){
        return view('Rent_Info.rent_info_user_view');
        
    }   
 
    public function create_user(){
        return view('Rent_Info.rent_info_create');
        
    }
    
    public function store(Request $request){
        $image=$request->file('image');
      
        $image->getClientOriginalName();
        
        $image->getClientOriginalExtension();
        
        $image->getRealPath();
        $image->getSize();
        $image->getMimeType();
        $path='uploads';
        $image->move($path,$image->getClientOriginalName()); 
       // $data= $request->all();
        $image2=$request->file('image2');
      
        $image2->getClientOriginalName();
        
        $image2->getClientOriginalExtension();
        
        $image2->getRealPath();
        $image2->getSize();
        $image2->getMimeType();
        $path2='uploads';
        $image2->move($path2,$image2->getClientOriginalName()); 
       
         $data=new Miaki_Model;
        
        $data->title=$request->title;
        $data->category=$request->category;
       $data->partner=$request->partner;
        $data->description=$request->description;
        $data->price=$request->price;
        $data->discount=$request->discount;
        $data->published=$request->published;
        $data->featured=$request->featured;
        $data->file =$image->getClientOriginalName();
        $data->file =$image2->getClientOriginalName();
        $data->save();
        return redirect('BT');
        
    }
    
    public function destroy(Request $request){
        $id=$request->id;
        $data=  Miaki_Model::find($id);
        $data->delete();
       return redirect('BT');
    }
    
    public function edit(Request $request){
         $id=$request->id;
        $data=  Miaki_Model::find($id);
        return view('Rent_Info.rent_info_edit')->with('query',$data);
         
    }
    
    public function update(Request $request){

          $image=$request->file('edit_image');
      
        $image->getClientOriginalName();
        
        $image->getClientOriginalExtension();
        
        $image->getRealPath();
        $image->getSize();
        $image->getMimeType();
        $path='uploads';
        $image->move($path,$image->getClientOriginalName()); 
       
        $image2=$request->file('edit_image2');
      
        $image2->getClientOriginalName();
        
        $image2->getClientOriginalExtension();
        
        $image2->getRealPath();
        $image2->getSize();
        $image2->getMimeType();
        $path2='uploads';
        $image2->move($path2,$image2->getClientOriginalName()); 
       
        $id=$request->id;
 $data= $request->all();
$data=Miaki_Model::find($id);
$data->id=$request->id;
        $data->title=$request->edit_title;
        $data->category=$request->edit_category;
       $data->partner=$request->edit_partner;
        $data->description=$request->edit_description;
        $data->price=$request->edit_price;
        $data->discount=$request->edit_discount;
        $data->published=$request->edit_published;
        $data->featured=$request->edit_featured;
        $data->file =$image->getClientOriginalName();
        $data->file =$image2->getClientOriginalName();
            
        $data->save();
        return redirect('BT');
    
}



}
