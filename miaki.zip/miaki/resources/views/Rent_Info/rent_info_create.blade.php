{!! Html::style('/css/bootstrap.min.css')!!}
{!! Html::style('/css/datatables.css')!!}
{!! Html::script('/js/bootstrap.min.js') !!}

{!! Html::script('/js/jquery-1.11.3.min.js') !!}
{!! Html::script('/js/datatables.js') !!}
{!! Form::open(['route'=>'mycont.store'])!!}
<table class="table table-hover">
    
    <tr>
        <th>Flat Type</th>
        <td>{!! Form::text('flat_type','',['class'=>'form-control'])!!}</td>
        
        
    </tr>
    <tr>
    <th>Monthly Rent</th>
        <td>{!! Form::text('monthly_rent','',['class'=>'form-control'])!!}</td>
        
        
    </tr>
    
    
    
    <tr>
        <td></td>
        <td>{!!Form::submit('save',['class'=>'btn btn-info'])!!}</td>
    </tr>
    
</table>
{!!Form::close()!!}