{!! Html::style('/css/bootstrap.min.css')!!}
{!! Html::style('/css/datatables.css')!!}
{!! Html::script('/js/bootstrap.min.js') !!}

{!! Html::script('/js/jquery-1.11.3.min.js') !!}
{!! Html::script('/js/datatables.js') !!}
<style>
    img{
        height: 120px;
        width:100px;
    }
</style>
<!--{!! Form::model($query, [
    'method' => 'PATCH',
    'route' => ['mycont.update', $query->id]
]) !!}-->
<table class="table table-hover">
    {!! Form::hidden('id',$query->id,array('class'=>'form-control','id'=>'id'))!!}
    
    <tr>
        <th>Title </th>
        <td>{!! Form::text('edit_title',$query->title,array('class'=>'form-control','id'=>'edit_title'))!!}</td>
        
        <th>Published</th>
         <td>{!!Form::radio('edit_published',$query->published,array('class'=>'','id'=>'yes'))!!}YES
         
             {!!Form::radio('edit_published',$query->published,array('id'=>'no'))!!}NO
         </td>
         
         <th>Featured</th>
         <td style="margin-left: -40px">{!!Form::radio('edit_featured',$query->featured,array('class'=>'','id'=>'yes'))!!}YES
         
           {!!Form::radio('edit_featured',$query->featured,array('class'=>'','id'=>'no'))!!}NO
         </td>
    </tr>
    
    
    <tr>
        <th>Category</th>
        <td>
            {!! Form::text('edit_category',$query->category,array('class'=>'form-control','id'=>'edit_category'))!!}
        </td>
        
        <th>Price</th>
        <td>{!!Form::text('edit_price',$query->price,array('class'=>'form-control','id'=>'edit_price'))!!}</td>
        
        <th>Discount(%)</th>
        <td>{!!Form::text('edit_discount',$query->discount,array('class'=>'form-control','id'=>'Edit_discount'))!!}</td>
    </tr> 
    
    <tr>
    <th>Partner</th>
        <td>
            {!! Form::text('edit_partner',$query->partner,array('class'=>'form-control','id'=>'edit_partner'))!!}
        </td>
        
        <th>File</th>
          <td>{!!Form::file('edit_image')!!}</td>
        </tr>
    
 <tr>
     <th>Description</th>
        <td>{!! Form::textarea('edit_description',$query->description,array('class'=>'form-control ','id'=>'edit_description','style'=>'height:160px; width:200px'))!!}</td>
        
        <th>Thambnall</th>
    
        <td>{!!Form::file('edit_image2')!!}</td> 
        <td>{{Html::image('uploads/'.$query->file)}}</td>
    </tr>
    <input type="hidden" name="_token" value="{{ csrf_token() }}">
</table>
<!--{!!Form::close()!!}-->